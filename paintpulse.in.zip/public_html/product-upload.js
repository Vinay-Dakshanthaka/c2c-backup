//firstore
import {
    firestore,
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc,
    setDoc,
    updateDoc,
    onSnapshot,
    addDoc,
    deleteDoc,
    deleteObject,
    or,
    and,
    limit,
    startAfter,
    endAt,
    orderBy,
    getCountFromServer,
    deleteField,
    arrayUnion
} from './assets/repository/initialize.js'

//Auth
import {
    auth,
    signOut,
    onAuthStateChanged,
    updatePassword,
    EmailAuthProvider,
    reauthenticateWithCredential,
} from './assets/repository/initialize.js'

//storage
import {
    storage,
    ref,
    uploadBytes,
    getDownloadURL,
} from './assets/repository/initialize.js'

const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
var userData = null;
var loggedIn = false;

// Function to check if the user is logged in
function isUserLoggedIn() {
    return !!auth.currentUser;
}

//--------------------------------------Event Listenser------------------------------------------- 
confirmLogoutBtn.addEventListener("click", () => {
    signOut(auth)
        .then(() => {
            window.location.href = "login.html";
        })
        .catch((error) => {
            console.error("Error during logout:", error);
        });
});


//--------------------------------------------------------------------------//
//-----------------------------cart dependency----------------------------//
//update cart function cart(dependency)
/**
 * 
 * @returns promise
 * 
 * requires: 
 * getCart()
 */
function updateCart() {
    return new Promise(async (resolve) => {
        console.log("from update cart")
        const shownCart = document.querySelector('#shown-cart')

        let cart = await getCart()
        console.log(cart.length)

        if (cart.length) {
            document.querySelectorAll('.cart').forEach(ele => ele.textContent = cart.length)
        }
        else {
            document.querySelectorAll('.cart').forEach(ele => ele.textContent = 0)
        }
        console.log("resolve")
        resolve()
    })
}

async function getCart() {
    return new Promise(async (resolve) => {
        if (loggedIn) {
            const cartSnapshot = await getDocs(collection(firestore, 'users', auth.currentUser.uid, 'cart'))
            if (cartSnapshot.empty) {
                resolve([])
            }
            let cart = []
            cartSnapshot.forEach(doc => {
                cart.push(doc.data())
            })
            resolve(cart)
        }
        else {
            const cartSnapshot = JSON.parse(sessionStorage.getItem('cart'))
            if (!cartSnapshot) {
                resolve([])
                return
            }
            var cart = []
            cartSnapshot.forEach(doc => {
                cart.push(doc)
            })
            resolve(cart)
        }
    })
}

//get user snapshot cart(dependency)
function getUserSnapshot(uid) {
    const userRef = doc(firestore, 'users', uid)
    console.log('3')
    return new Promise((resolve, reject) => {
        resolve(getDoc(userRef))
    })
}

/**
 * Necessary fucntions to call after pageload
 */
async function postPageLoadFunctions() {
    await updateCart();
    // await fetchNavCategories();
}

//------------------------------loading and role access-----------------------------
onAuthStateChanged(auth, async (user) => {
    if (user) {
        loggedIn = true
        onLoggedIn();
        document.querySelector('#logout-btn').style.display = 'block';
        const docRef = doc(firestore, "users", user.uid);
        const docSnap = getDoc(docRef);
        docSnap.then(async (docSnapshot) => {
            if (docSnapshot.exists()) {
                userData = docSnapshot.data();
                roleAccess(userData.role);
                updateProfileName(userData.role, userData.firstName);
                updateProfilePicture(userData.role, userData.profilePicture)
            }
        });
    } else {
        document.querySelector('#logout-btn').style.display = 'none';
        window.location.href = "login.html";
    }
    await postPageLoadFunctions();
});

function roleAccess(role) {
    const roleMap = new Map([
        ["ADMIN", "adminAppbar"],
        ["CUSTOMER", "customerAppbar"],
        ["AGENT", "agentAppbar"],
    ]);
    const appbarList = document.querySelectorAll(`#${roleMap.get(role)}`);
    appbarList.forEach((appbar) => {
        appbar.classList.remove("d-none");
    })
}

function updateProfileName(role, fullName) {
    console.log(fullName)
    let profileNameElement;
    switch (role) {
        case 'CUSTOMER':
            profileNameElement = document.getElementById('customerAppbar').querySelector('.profile-name');
            break;
        case 'AGENT':
            profileNameElement = document.getElementById('agentAppbar').querySelector('.profile-name');
            break;
        case 'ADMIN':
            profileNameElement = document.getElementById('adminAppbar').querySelector('.profile-name');
            break;
        default:
            console.error('Unknown role:', role);
            return;
    }
    profileNameElement.textContent = fullName;
}

function updateProfilePicture(role, profilePicture) {
    let profilePictureElement;
    const defaultProfilePicture = 'https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp';

    switch (role) {
        case 'CUSTOMER':
            profilePictureElement = document.getElementById('customerAppbar').querySelector('#profile-picture');
            break;
        case 'AGENT':
            profilePictureElement = document.getElementById('agentAppbar').querySelector('#profile-picture');
            break;
        case 'ADMIN':
            profilePictureElement = document.getElementById('adminAppbar').querySelector('#profile-picture');
            break;
        default:
            console.error('Unknown role:', role)
            return;
    }

    // Check if profilePicture is empty or undefined
    if (profilePicture && profilePicture.trim() !== '') {
        profilePictureElement.src = profilePicture;
    } else {
        // Set to the default profile picture if no picture is provided
        profilePictureElement.src = defaultProfilePicture;
    }
}

//to execut upon logging in
function onLoggedIn() {
    var navItemList = document.querySelectorAll(".loggedIn");
    navItemList.forEach((navItem) => {
        navItem.style.display = "block";
    });

    navItemList = document.querySelectorAll(".loggedOut");
    navItemList.forEach((navItem) => {
        navItem.style.display = "none";
    });
}

//to execute upon logging out
function onLoggedOut() {
    var navItemList = document.querySelectorAll(".loggedOut");
    navItemList.forEach((navItem) => {
        navItem.style.display = "block";
    });

    navItemList = document.querySelectorAll(".loggedIn");
    navItemList.forEach((navItem) => {
        navItem.style.display = "none";
    });
}

//------------------------ Manage Manufacturer--------------------------------------
document.querySelector('#manufacturer-dropdown').addEventListener('click',loadAllManufacturers);
/**
 * Add a click event listener to open the manufacturer modal
 * @return mydev 
 */
const openManufacturerModalButton = document.getElementById('add-manufacturer-button');
openManufacturerModalButton.addEventListener('click', () => {
    document.getElementById('manufacturerName').value = '';
    populateManufacturerList();
});

/**
 * save the manufacturers 
 * @returns sid
 */
document.getElementById('saveManufacturerButton').addEventListener('click', async () => {
    const manufacturerName = document.getElementById('manufacturerName').value;
    const manufacturerImageInput = document.getElementById('manufacturerImage')
    if (manufacturerName && manufacturerImageInput.files.length > 0) {
        const manufacturerImageFile = manufacturerImageInput.files[0];
        try {
            await addManufacturer(manufacturerName, manufacturerImageFile);
            console.log('Manufacturer added successfully');
            displayMessage('Manufacturer added successfully!', 'success');
            populateManufacturerList();
            document.getElementById('manufacturerName').value = '';
            // Clear the file input to allow selecting a new image for the next manufacturer
            manufacturerImageInput.value = '';
        } catch (error) {
            console.error('Error adding manufacturer:', error);
        }
    } else {
        console.error('Manufacturer name and image are required.');
        displayMessage('Manufacturer name and image are required.', 'danger');
    }
});

/**
 * @return sid
 * @param {*} manufacturerName
 * @param {*} manufacturerImageFile
 * @returns 
 */
async function addManufacturer(manufacturerName, manufacturerImageFile) {
    try {
        // Upload the manufacturer image to Storage
        const storageRef = ref(storage, 'manufacturer_images/' + manufacturerImageFile.name);
        await uploadBytes(storageRef, manufacturerImageFile);

        // Get the download URL of the uploaded image
        const imageUrl = await getDownloadURL(storageRef);

        // Add manufacturer details to Firestore
        const manufacturerRef = collection(firestore, 'manufacturers');
        const docRef = await addDoc(manufacturerRef, { name: manufacturerName, imageUrl: imageUrl });

        // Update the manufacturerId with the document ID
        await updateDoc(docRef, { manufacturerId: docRef.id });

        return docRef.id;
    } catch (error) {
        console.error('Error adding manufacturer:', error);
        throw error;
    }
}

/**
 * populate manufacturers when any will happened in the manufacturer table
 * @returns mydev
 */
function populateManufacturerList() {
    const manufacturerList = document.getElementById('manufacturerList');
    getDocs(collection(firestore, 'manufacturers'))
        .then((manufacturers) => {
            manufacturerList.innerHTML = '';
            manufacturers.forEach((manufacturerDoc) => {
                const manufacturer = manufacturerDoc.data();
                const row = document.createElement('tr');
                row.innerHTML = `
                                <td>${manufacturer.name}</td>
                                <td>
                                    <button class="btn btn-sm btn-primary edit">Edit</button>
                                    <button class="btn btn-sm btn-danger delete" >Delete</button>
                                </td>
                            `;
                manufacturerList.appendChild(row);
                row.querySelector('.edit').addEventListener('click', () => editManufacturer(manufacturer.manufacturerId, manufacturer.name))
                row.querySelector('.delete').addEventListener('click', () => deleteManufacturer(manufacturer.manufacturerId))
            });
        })
        .catch((error) => {
            console.error('Error getting manufacturers:', error);
        });
}


/**
 * @return mydev
 * Edit Manufacturer
 * @param {*} manufacturerId 
 * @param {*} manufacturerName 
 */
async function editManufacturer(manufacturerId, manufacturerName) {
    console.log(manufacturerId)
    console.log('from editmanufacturer')
    const updatedManufacturerName = prompt('Edit Manufacturer Name:', manufacturerName);
    if (updatedManufacturerName !== null) {
        const manufacturerCollection = collection(firestore, 'manufacturers')
        const manufacturerSnapshot = await getDocs(query(manufacturerCollection, where('manufacturerId', '==', manufacturerId)))
        if (!manufacturerSnapshot.empty) {
            console.log(manufacturerSnapshot.docs[0].data())
            updateDoc(manufacturerSnapshot.docs[0].ref, { name: updatedManufacturerName })
                .then(() => {
                    console.log(`Successfully Updated to ${updatedManufacturerName}`)
                    console.log('Manufacturer updated successfully');
                    displayMessage('Manufacturer updated successfully!', 'success');
                    document.querySelector('#manufacturer-dropdown').addEventListener('click', loadAllManufacturers)
                    populateManufacturerList();
                })
                .catch((error) => {
                    console.error('Error updating manufacturer:', error);
                });
        }
    }
}


/**
 * To deleting the manufacturer using manufacturerId
 * @param {*} manufacturerId 
 */
async function deleteManufacturer(manufacturerId) {
    const confirmation = confirm('Are you sure you want to delete this manufacturer?');
    if (confirmation) {
        try {
            const manufacturerCollection = collection(firestore, 'manufacturers');
            const manufacturerSnapshot = await getDocs(query(manufacturerCollection, where('manufacturerId', '==', manufacturerId)));

            if (!manufacturerSnapshot.empty) {
                const manufacturerDoc = manufacturerSnapshot.docs[0];
                const manufacturerData = manufacturerDoc.data();

                // Extract the file name from the image URL
                const fileName = getManufacturerImageFileName(manufacturerData.imageUrl);

                // Delete the manufacturer image from storage
                if (fileName) {
                    const storageRef = ref(storage, 'manufacturer_images/' + fileName);

                    await deleteObject(storageRef)
                        .then(() => {
                            console.log('Image deleted from storage successfully.');
                        })
                        .catch((error) => {
                            console.error('Error deleting image from storage:', error);
                        });
                }

                // Delete the manufacturer document from Firestore
                await deleteDoc(manufacturerDoc.ref);
                console.log('Manufacturer deleted successfully');
                displayMessage('Manufacturer deleted successfully!', 'success');
                document.querySelector('#manufacturer-dropdown').addEventListener('click', loadAllManufacturers)
                populateManufacturerList();
            }
        } catch (error) {
            console.error('Error deleting manufacturer:', error);
        }
    }
}

/**
 * Extracts the file name from the image URL
 * @param {string} imageUrl 
 * @returns {string} File name
 */
function getManufacturerImageFileName(imageUrl) {
    const url = new URL(imageUrl);
    return decodeURIComponent(url.pathname).replace(/^.*[\\\/]/, '');
}

/**
 * to fetch manufacturers in modal
 * @returns mydev
 */
async function loadAllManufacturers(event) {
    event.preventDefault();
    console.log("567")
    const select = document.querySelector('#manufacturer-dropdown')
    select.innerHTML = `<option value="">
                                Loading ...
                            </option>`
    const manufacturerSnapshot = await getDocs(collection(firestore, 'manufacturers'))
    if (!manufacturerSnapshot.empty) {
        select.removeEventListener('click', loadAllManufacturers)
        select.innerHTML = ``
        const option = document.createElement('option')
        option.innerHTML = `Please select`
        select.appendChild(option)
        manufacturerSnapshot.forEach(doc => {
            const option = document.createElement('option')
            option.setAttribute('value', doc.data().name)
            option.setAttribute('data-id', doc.data().manufacturerId)
            option.innerHTML = `${doc.data().name}`
            select.appendChild(option)
        })
        // document.querySelector('#colorShadeDropdown').click()
    }
    else {
        select.innerHTML = `<option value="">Please select</option>`
        displayMessage('No manufactures added!', 'danger')
    }
}
//----------------------------------------------------------------------------------------

document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
// -------------------------- categories section------------------------------------------
const openCategoryModalButton = document.getElementById('add-category-button');
openCategoryModalButton.addEventListener('click', () => {
    document.getElementById('categoryName').value = '';
    populateCategoryList();
});

/**
 * save the categories 
 * @returns mydev
 */
document.getElementById('saveCategoryButton').addEventListener('click', async () => {
    const categoryName = document.getElementById('categoryName').value;
    const categoryImageInput = document.getElementById('categoryImage');

    if (categoryName && categoryImageInput.files.length > 0) {
        const categoryImageFile = categoryImageInput.files[0];
        try {
            await addCategory(categoryName, categoryImageFile);
            console.log('Category added successfully');
            displayMessage('Category added successfully!', 'success');
            populateCategoryList();
            document.getElementById('categoryName').value = '';
            // Clear the file input to allow selecting a new image for the next category
            categoryImageInput.value = '';
        } catch (error) {
            console.error('Error adding category:', error);
        }
    } else {
        console.error('Category name and image are required.');
        displayMessage('Category name and image are required', 'danger');
    }
});

/**
 * @return sid
 * @param {*} categoryName 
 * @param {*} categoryImageFile // Add the category image file parameter
 * @returns 
 */
async function addCategory(categoryName, categoryImageFile) {
    try {
        // Upload the category image to Storage
        const storageRef = ref(storage, 'category_images/' + categoryImageFile.name);
        await uploadBytes(storageRef, categoryImageFile);

        // Get the download URL of the uploaded image
        const imageUrl = await getDownloadURL(storageRef);

        // Add category details to Firestore
        const categoryRef = collection(firestore, 'categories');
        const docRef = await addDoc(categoryRef, { name: categoryName, imageUrl: imageUrl });

        // Update the categoryId with the document ID
        await updateDoc(docRef, { categoryId: docRef.id });

        return docRef.id;
    } catch (error) {
        console.error('Error adding category:', error);
        throw error;
    }
}

/**
 * populate categories when any will happened in the category table
 * @returns mydev
 */
function populateCategoryList() {
    const categoryList = document.getElementById('categoryList');
    getDocs(collection(firestore, 'categories'))
        .then((categories) => {
            categoryList.innerHTML = '';
            categories.forEach((categoryDoc) => {
                const category = categoryDoc.data();
                const row = document.createElement('tr');
                row.innerHTML = `
                                <td>${category.name}</td>
                                <td>
                                    <button class="btn btn-sm btn-primary edit">Edit</button>
                                    <button class="btn btn-sm btn-danger delete" >Delete</button>
                                </td>
                            `;
                categoryList.appendChild(row);
                row.querySelector('.edit').addEventListener('click', () => editCategory(category.categoryId, category.name))
                row.querySelector('.delete').addEventListener('click', () => deleteCategory(category.categoryId))
            });
        })
        .catch((error) => {
            console.error('Error getting manufacturers:', error);
        });
}

/**
 * @return mydev
 * Edit Category
 * @param {*} categoryId 
 * @param {*} categoryName 
 */
async function editCategory(categoryId, categoryName) {
    console.log(categoryId)
    console.log('from editcategory')
    const updatedCategoryName = prompt('Edit Category Name:', categoryName);
    if (updatedCategoryName !== null) {
        const categoryCollection = collection(firestore, 'categories')
        const categorySnapshot = await getDocs(query(categoryCollection, where('categoryId', '==', categoryId)))
        if (!categorySnapshot.empty) {
            console.log(categorySnapshot.docs[0].data())
            updateDoc(categorySnapshot.docs[0].ref, { name: updatedCategoryName })
                .then(() => {
                    console.log(`Successfully Updated to ${updatedCategoryName}`)
                    console.log('Category updated successfully');
                    displayMessage('category updated successfully!', 'success');
                    document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
                    populateCategoryList();
                })
                .catch((error) => {
                    console.error('Error updating category:', error);
                });
        }
    }
}

/**
 * To delete the category using categoryId
 * @param {*} categoryId 
 */
async function deleteCategory(categoryId) {
    console.log(categoryId);
    const confirmation = confirm('Are you sure you want to delete this category?');
    if (confirmation) {
        try {
            const categoryCollection = collection(firestore, 'categories');
            const categorySnapshot = await getDocs(query(categoryCollection, where('categoryId', '==', categoryId)));

            if (!categorySnapshot.empty) {
                const categoryDoc = categorySnapshot.docs[0];
                const categoryData = categoryDoc.data();

                // Extract the file name from the image URL
                const fileName = getCategoryImageFileName(categoryData.imageUrl);

                // Delete the category image from storage
                if (fileName) {
                    const storageRef = ref(storage, 'category_images/' + fileName);

                    await deleteObject(storageRef)
                        .then(() => {
                            console.log('Image deleted from storage successfully.');
                        })
                        .catch((error) => {
                            console.error('Error deleting image from storage:', error);
                        });
                }

                // Delete the category document from Firestore
                await deleteDoc(categoryDoc.ref);

                console.log('Category deleted successfully');
                displayMessage('Category deleted successfully!', 'success');
                document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories);
                populateCategoryList();
            }
        } catch (error) {
            console.error('Error deleting category:', error);
        }
    }
}

/**
 * Extracts the file name from the image URL
 * @param {string} imageUrl 
 * @returns {string} File name
 */
function getCategoryImageFileName(imageUrl) {
    const url = new URL(imageUrl);
    return decodeURIComponent(url.pathname).replace(/^.*[\\\/]/, '');
}

/**
 * to fetch categories in model
 * @returns mydev
 */
async function loadAllCategories(event) {
    event.preventDefault();
    console.log("890")
    const select = document.querySelector('#categoryDropdown')
    select.innerHTML = `<option value="">
                                Loading ...
                            </option>`
    const categorySnapshot = await getDocs(collection(firestore, 'categories'))
    if (!categorySnapshot.empty) {
        select.removeEventListener('click', loadAllCategories)
        select.innerHTML = ``
        const option = document.createElement('option')
        option.innerHTML = `Please select`
        select.appendChild(option)
        categorySnapshot.forEach(doc => {
            const option = document.createElement('option')
            option.setAttribute('value', doc.data().name)
            option.setAttribute('data-id', doc.data().categoryId)
            option.innerHTML = `${doc.data().name}`
            select.appendChild(option)
        })
        // document.querySelector('#colorShadeDropdown').click()
    }
    else {
        select.innerHTML = `<option value="">Please select</option>`
        displayMessage('No categories added!', 'danger')
    }
}
//------------------------------------------------------------------------------------


// ---------------------------- ColorAdd Manage---------------------------------------
/**
 * save the color for product
 */
document.querySelector('#save-color-button').addEventListener('click', saveColorFoProducts)

/**
 * to load the colors when open the colormodel
 * @returns mydev
 */
const openAddColorModel = document.querySelector('#add-color-model')
openAddColorModel.addEventListener('click', () => {
    document.getElementById('color-name').value = ''
    document.getElementById('color-hexcode').value = ''
    document.getElementById('color-price').value = ''
    fetchColorsForProducts();
})

/**
 * save color for product
 * @returns mydev
 */
async function saveColorFoProducts(){  
    const colorName  = document.querySelector('#color-name').value;
    const colorhexcode  = document.querySelector('#color-hexcode').value;
    const colorPrice  = document.querySelector('#color-price').value;
    
    if(!colorName || !colorhexcode || !colorPrice){
        displayMessage('Please Enter All field','danger');

        if (!colorName) {
            document.querySelector('#color-name').focus();
        } else if (!colorhexcode) {
            document.querySelector('#color-hexcode').focus();
        } else if (!colorPrice) {
            document.querySelector('#color-price').focus();
        }
        return;
    }
    
    const colorsRef =  collection(firestore,'colors')
    const docRef = await addDoc(colorsRef,
        {
            colorName: colorName,
            colorhexcode: colorhexcode,
            colorPrice: colorPrice
        });
    await updateDoc(docRef, { colorId: docRef.id });
    fetchColorsForProducts();
    displayMessage('colorDetails added successfully', 'success');
    document.querySelector('#color-name').value = ''
    document.querySelector('#color-hexcode').value = ''
    document.querySelector('#color-price').value = ''
}

/**
 * fetch colors for particuler product
 * @returns mydev
 */
async function fetchColorsForProducts(){
    const productColorRef = collection(firestore,'colors');
    const productSnapshot = await getDocs(productColorRef);
    let productColorContainer = document.querySelector('#color-pro-container');
    if (!productSnapshot.empty) {
        productColorContainer.removeEventListener('click', fetchColorsForProducts);
        productColorContainer.innerHTML = ''
        productSnapshot.forEach((doc) => {

        const docData = doc.data();
        // console.log(docData)
        const productDiv = document.createElement('div');
        productDiv.classList.add('colorboxcontainer','border')
        productDiv.innerHTML = `
                        <div id="colordisplay border-bottom" style="background-color: ${docData.colorhexcode}; padding: 2em 5em;" data-colorId ="product-${docData.colorId}" class=" colorbox">
                        </div>
                            <div class="d-flex align-items-center justify-content-between p-2">
                            <div class="m-r-30">
                                <p id="color-name-display" class="m-0">${docData.colorName}</p>
                                <p id="color-price-display" class="m-0">${docData.colorPrice} /Ltr</p>
                            </div>
                            <button class="edit" id="selected-product-color">
                                <i class="fa-regular fa-pen-to-square" 
                                 data-colorId="${doc.id}" data-colorName="${docData.colorName}"
                                 data-colorPrice="${docData.colorPrice}"></i>
                            </button>

                            <button class="delete" id="selected-product-color">
                                <i class="fa-solid fa-trash" 
                                 data-colorId="${doc.id}" data-colorName="${docData.colorName}"
                                 data-colorPrice="${docData.colorPrice}"></i>
                            </button>
                        </div> 
                        `
            productColorContainer.appendChild(productDiv);
            productDiv.querySelector('.delete').addEventListener('click', async (event) => {
                event.preventDefault();
               if(event.target){
                    const colorId = event.target.getAttribute('data-colorId')
                    deleteColor(colorId)
               }
            })

            productDiv.querySelector('.edit').addEventListener('click', async (event) => {
                event.preventDefault();
                if (event.target) {
                    // console.log(event.target);
                    const colorId = event.target.getAttribute('data-colorId')
                    const colorPrice = event.target.getAttribute('data-colorPrice')
                    editColor(colorId,colorPrice)
                }
            })
        });
    }
    else {
        productColorContainer.innerHTML = `<option value="">Colors not exists for this product</option>`
        displayMessage('Colors not exists for this product!', 'danger')
    }
}

/**
 * edit the color based on the colorId and colorPrice
 * @param {*} colorId 
 * @param {*} colorPrice 
 */
async function editColor(colorId, colorPrice) {
    console.log(colorId)
    console.log('from color')
    const updatedColorPrice = prompt('Edit Color Price:', colorPrice);
    if (updatedColorPrice !== null) {
        const colorCollection = collection(firestore, 'colors')
        const colorSnapshot = await getDocs(query(colorCollection, where('colorId', '==', colorId)))
        if (!colorSnapshot.empty) {
            console.log(colorSnapshot.docs[0].data())
            updateDoc(colorSnapshot.docs[0].ref, { colorPrice : updatedColorPrice })
                .then(() => {
                    console.log(`Successfully Updated to ${updatedColorPrice}`)
                    console.log('Color updated successfully');
                    displayMessage('color updated successfully!', 'success');
                    // document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
                    fetchColorsForProducts();
                })
                .catch((error) => {
                    console.error('Error updating color:', error);
                });
        }
    }
}

/**
 * delete color based on the colorId
 * @param {*} colorId 
 */
async function deleteColor(colorId) {
    console.log(colorId);
    const confirmation = confirm('Are you sure you want to delete this color?');
    if (confirmation) {
        try {
            const colorCollection = collection(firestore, 'colors')
            const colorSnapshot = await getDocs(query(colorCollection, where('colorId', '==', colorId)))
            if (!colorSnapshot.empty) {
                await deleteDoc(colorSnapshot.docs[0].ref)
            }
            console.log('Color deleted successfully');
            displayMessage('Color deleted successfully!', 'success');
            // document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
            fetchColorsForProducts();
        } catch (error) {
            console.error('Error deleting color:', error);
        }
    }
}
//-----------------------------------------------------------------------------------

//------------------------------------ Select colors for product---------------------
const openSelectColorModel = document.querySelector('#select-color-model')
openSelectColorModel.addEventListener('click',()=>{
    fetchColorsForSelect();
})


var selectedColorIds = []
var selectedColorHexcode = []
const selectedColorsContainer = document.querySelector('.selected-color-container');
const colorCountElement = document.querySelector('.selected-color-counter');
/**
 * fetch colors to select the colors
 * @returns mydev
 */
async function fetchColorsForSelect(){
    selectedColorIds=[]
    selectedColorHexcode = []
    const productColorRef = collection(firestore,'colors');
    const productSnapshot = await getDocs(productColorRef);
    let productColorContainer = document.querySelector('#color-select-container');
    if(!productSnapshot.empty){
        console.log(selectedColorIds)
        console.log(selectedColorHexcode)
        productColorContainer.removeEventListener('click',fetchColorsForSelect);
        productColorContainer.innerHTML = ''
        selectedColorsContainer.innerHTML = ''
        productSnapshot.forEach((doc)=>{
        const docData = doc.data();
        console.log(docData)
        const productDiv = document.createElement('div');
        productDiv.classList.add('colorboxcontainer','border')
        productDiv.innerHTML = `
                        <div id="colordisplay border-bottom" style="background-color: ${docData.colorhexcode}; padding: 2em 5em;" data-colorId ="product-${docData.colorId}" class=" colorbox">
                        </div>
                            <div class="d-flex align-items-center justify-content-between p-2">
                            <div class="m-r-30">
                                <p id="color-name-display" class="m-0">${docData.colorName}</p>
                                <p id="color-price-display" class="m-0">${docData.colorPrice} /Ltr</p>
                            </div>
                            <a class="select-color" id="selected-product-color" 
                            data-colorId="${doc.id}" 
                            data-colorName="${docData.colorName}"
                            data-colorPrice="${docData.colorPrice}" 
                            data-colorHexcode="${docData.colorhexcode}">
                                select
                            </a>
                        </div> 
                        `           
            productColorContainer.appendChild(productDiv);  
            productDiv.querySelector('.select-color').addEventListener('click',async(event)=>{
                event.preventDefault();
                if(event.target){
                    // console.log(event.target);
                    const colorId = event.target.getAttribute('data-colorId');
                    const colorHexcode = event.target.getAttribute('data-colorHexcode')
                    
                    if(!selectedColorIds.includes(colorId)){
                       selectedColorIds.push(colorId);
                       selectedColorHexcode.push(colorHexcode);
                    }
                    updateSelectedColorsDisplay();
                }
            })
        });   
    }
    else{
        productColorContainer.innerHTML = `<option value="">Colors not exists for this product</option>`
        displayMessage('Colors not exists for this product!', 'danger')  
    }
}

/**
 * selected colors
 */

function updateSelectedColorsDisplay(){
    selectedColorsContainer.innerHTML = ' ';
    colorCountElement.textContent = selectedColorIds.length > 0 ? `${selectedColorIds.length} Color Selected` : 'No colors selected';
    console.log("update")
    selectedColorHexcode.forEach((colorHexcode, index) => {

        const colorDiv = document.createElement('div');
        colorDiv.innerHTML= 
        `<div style="background-color: ${colorHexcode}; width: 50px; height: 50px; margin-right: 10px;" 
        title="Color ${index + 1}: ${colorHexcode}">
        </div>
        <button class="delete" data-index="${index}">delete</button>
        `
        colorDiv.querySelector('.delete').addEventListener('click', () => {
            if(index>-1){
                console.log(index)
                selectedColorIds.splice(index, 1);
                selectedColorHexcode.splice(index, 1);
                updateSelectedColorsDisplay();
            }
        });
        console.log(selectedColorIds)
        console.log(selectedColorHexcode)
        selectedColorsContainer.appendChild(colorDiv);
    });
}
// --------------------------------------------------------------------------------

//------------------------------ Add sizes------------------------------------------
/**
 * save the size for product
 */
document.querySelector('#save-size-button').addEventListener('click',saveSizesFoProducts)

/**
 * to load the sizes when open the sizemodel
 * @returns mydev
 */
const openAddSizesModel = document.querySelector('#add-size-model')
openAddSizesModel.addEventListener('click',()=>{
    fetchSizesForProduct();
    document.getElementById('product-size').value = ''
})

/**
 * save sizes for product
 * @returns mydev
 */
async function saveSizesFoProducts(){  
    const productSize  = document.querySelector('#product-size').value;
    if(!productSize){
        displayMessage('Please Enter All fields!','danger');
        if (!productSize) {
            document.querySelector('#product-size').focus();
        }
        return;
    }
    const colorsRef =  collection(firestore,'sizes')
    const docRef = await addDoc(colorsRef,
        {
           size : productSize,
           unit : "ltr"
        });
    await updateDoc(docRef , {sizeId : docRef.id});
    fetchSizesForProduct();
    displayMessage('Product size added successfully','success');
    document.querySelector('#product-size').value = ''
}

/**
 * fetch sizes for particuler product
 * @returns mydev
 */
async function fetchSizesForProduct(){
    console.log("1")
    const productSizesRef = collection(firestore,'sizes');
    const productSnapshot = await getDocs(productSizesRef);
    // console.log(productSnapshot)
    let productSizesContainer = document.querySelector('#product-size-list');
    if(!productSnapshot.empty){
        productSizesContainer.removeEventListener('click',fetchSizesForProduct);
        selectedColorsContainer.innerHTML = ''
        productSizesContainer.innerHTML = ''
        productSnapshot.forEach((doc)=>{
        const docData = doc.data();
        console.log(docData)
        const productRow = document.createElement('tr');
        productRow.innerHTML = `
                        <td data-sizeId=${docData.sizeId}>${docData.size} &nbsp ${docData.unit}</td>
                        <td>
                            <button class="btn btn-sm btn-primary edit"
                             data-sizeId="${docData.sizeId}"
                             data-size="${docData.size}">Edit</button>
                            <button class="btn btn-sm btn-danger delete"
                             data-sizeId='${docData.sizeId}'
                             data-size="${docData.size}">Delete</button>
                        </td>
                        `
            console.log(productRow)
            productSizesContainer.appendChild(productRow);

            productRow.querySelector('.edit').addEventListener('click', async (event) => {
                event.preventDefault();
                if(event.target){
                    const sizeId = event.target.getAttribute('data-sizeId');
                    const size = event.target.getAttribute('data-size')
                    editSize(sizeId,size)
                }
            });

            productRow.querySelector('.delete').addEventListener('click', async (event) => {
                event.preventDefault();
                if(event.target){
                    const sizeId = event.target.getAttribute('data-sizeId');
                    deleteSize(sizeId);
                }
            })

        });
    }
    else {
        productSizesContainer.innerHTML = `<option value="">Colors not exists for this product</option>`
        displayMessage('Sizes not exists for this product!', 'danger')
    }
}

/**
 * edit the size based on the szieId and size
 * @param {*} sizeId 
 * @param {*} size 
 */
async function editSize(sizeId,size) {
    console.log(sizeId)
    console.log('from color')
    const updatedsize = prompt('Edit Color Price:', size);
    if (updatedsize !== null) {
        const sizeCollection = collection(firestore, 'sizes')
        const sizeSnapshot = await getDocs(query(sizeCollection, where('sizeId', '==', sizeId)))
        if (!sizeSnapshot.empty) {
            console.log(sizeSnapshot.docs[0].data())
            updateDoc(sizeSnapshot.docs[0].ref, { size : updatedsize})
                .then(() => {
                    console.log(`Successfully Updated to ${updatedsize}`)
                    console.log('Color updated successfully');
                    displayMessage('size updated successfully!', 'success');
                    // document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
                    fetchSizesForProduct();
                })
                .catch((error) => {
                    console.error('Error updating size:', error);
                });
        }
    }
}

/**
 * delete color based on the colorId
 * @param {*} colorId 
 */
async function deleteSize(sizeId) {
    console.log(sizeId);
    const confirmation = confirm('Are you sure you want to delete this color?');
    if (confirmation) {
        try {
            const sizeCollection = collection(firestore, 'sizes')
            const sizeSnapshot = await getDocs(query(sizeCollection, where('sizeId', '==', sizeId)))
            if (!sizeSnapshot.empty) {
                await deleteDoc(sizeSnapshot.docs[0].ref)
            }
            console.log('Color deleted successfully');
            displayMessage('Color deleted successfully!', 'success');
            // document.querySelector('#categoryDropdown').addEventListener('click', loadAllCategories)
            fetchSizesForProduct();
        } catch (error) {
            console.error('Error deleting size:', error);
        }
    }
}
// ---------------------------------------------------------------------------------------

// ------------------------------------ Select the sizes----------------------------------
var selectedSizeIds = [];
var selectedSize = []
const selectedSizesContainer = document.querySelector('.selected-size-container');
const sizeCountElement = document.querySelector('.selected-size-counter')

/**
 * open select size model
 * 
 */
const openSelectSizeModel = document.querySelector('#select-size-model')
openSelectSizeModel.addEventListener('click',()=>{
    fetchSizesForSelect();
})

/**
 * fetch the sizes for Select 
 */
async function fetchSizesForSelect(){
    console.log("1")
    const productSizesRef = collection(firestore,'sizes');
    const productSnapshot = await getDocs(productSizesRef);
    // console.log(productSnapshot)
    let productSizesContainer = document.querySelector('#select-product-size-list');
    if(!productSnapshot.empty){
        selectedSizeIds = [];
        selectedSize = []
        console.log(selectedSizeIds)
        console.log(selectedSize)
        productSizesContainer.removeEventListener('click',fetchSizesForSelect);
        productSizesContainer.innerHTML = ''
        selectedSizesContainer.innerHTML = ''
        productSnapshot.forEach((doc)=>{
        const docData = doc.data();
        console.log(docData)
        const productRow = document.createElement('tr');
        productRow.innerHTML = `
                        <td data-sizeId=${docData.sizeId}>${docData.size} &nbsp ${docData.unit}</td>
                        <td>
                            <button class="btn btn-sm btn-primary select"
                             data-sizeId="${docData.sizeId}"
                             data-size="${docData.size}">Select</button>
                        </td>
                        `       
            console.log(productRow)                
            productSizesContainer.appendChild(productRow); 
            
            productRow.querySelector('.select').addEventListener('click',async(event)=>{
                event.preventDefault();
                if(event.target){
                    const sizeId = event.target.getAttribute('data-sizeId');
                    const size = event.target.getAttribute('data-size')
                    if(!selectedSizeIds.includes(sizeId)){
                        selectedSizeIds.push(sizeId);
                        selectedSize.push(size);
                     }
                    updateSelectedSizesDisplay();
                }
            });
        });
    }
    else{
        productSizesContainer.innerHTML = `<option value="">Colors not exists for this product</option>`
        displayMessage('Sizes not exists for this product!', 'danger')  
    }
}

/**
 * update selected sizes in the select size model
 * @returns mydev
 */

function updateSelectedSizesDisplay(){
    selectedSizesContainer.innerHTML = ' ';
    sizeCountElement.textContent = selectedSizeIds.length > 0 ? `${selectedSizeIds.length} Size Selected` : 'No Sizes selected';
    console.log("update")
    selectedSize.forEach((size, index) => {
        const sizeDiv = document.createElement('div');
        sizeDiv.innerHTML= 
        `<div; width: 50px; height: 50px; margin-right: 10px;" 
        title="Color ${index + 1}: ${size}">${size}
        </div>
        <button class="delete btn btn-danger mb-3" data-index="${index}" >delete</button>
        `
        sizeDiv.querySelector('.delete').addEventListener('click', () => {
            if(index>-1){
                console.log(index)
                selectedSizeIds.splice(index, 1);
                selectedSize.splice(index, 1);
                selectedSizesContainer.removeChild(sizeDiv);
                updateSelectedColorsDisplay();
            }
        });
        selectedSizesContainer.appendChild(sizeDiv);
        console.log(selectedSizeIds)
        console.log(selectedSize)
    });
}
// --------------------------------------------------------------------------------------


// //------------------------------------------------------------------------------
// // // Initialize an empty array to store selected colors
// // const selectedColors = [];
// // document.getElementById('addColorButton').addEventListener('click', function () {
// //     const productColorInput = document.getElementById('productColor');
// //     const colorValue = productColorInput.value;

// //     if (colorValue) {
// //         // Add the selected color to the array
// //         selectedColors.push(colorValue);

// //         // Update the list of selected colors
// //         updateSelectedColorsList();

// //         // Clear the input field
// //         productColorInput.value = "";
// //     }
// // });

// // Function to update the list of selected colors
// function updateSelectedColorsList() {
//     const selectedColorsContainer = document.getElementById('selectedColorsContainer');
//     selectedColorsContainer.innerHTML = "";

//     selectedColors.forEach((color, index) => {
//         const colorContainer = document.createElement('div');
//         colorContainer.classList.add('selected-color-container');

//         const colorInput = document.createElement('input');
//         colorInput.type = 'color';
//         colorInput.value = color;
//         colorInput.disabled = true;

//         const removeButton = document.createElement('button');
//         removeButton.innerText = 'Remove';
//         removeButton.classList.add('remove-button');
//         removeButton.addEventListener('click', () => removeSelectedColor(index));

//         colorContainer.appendChild(colorInput);
//         colorContainer.appendChild(removeButton);

//         selectedColorsContainer.appendChild(colorContainer);
//     });
// }

// // Function to remove a selected color
// function removeSelectedColor(index) {
//     selectedColors.splice(index, 1);
//     updateSelectedColorsList();
// }

// // Function to clear the selected colors array
// function clearSelectedColors() {
//     selectedColors.length = 0;
//     updateSelectedColorsList();
// }

// ------------------------ Upload Product ---------------------------------
// Add a click event listener to the Upload Product
const uploadProductButton = document.getElementById('uploadProductButton');
uploadProductButton.addEventListener('click', uploadProduct);

// Function to upload image and product information
// var newProductArrivalStatusYes = document.querySelector('#new-product-arrival-yes');
// var newProductArrivalStatusNo = document.querySelector('#new-product-arrival-no');
// var newProductArrivalStatus = false;
// newProductArrivalStatusYes.addEventListener('change', function () {
//     if (this.checked) {
//         newProductArrivalStatus = true;
//         newProductArrivalStatusNo.checked = false;
//     }
// });

// newProductArrivalStatusNo.addEventListener('change', function () {
//     if (this.checked) {
//         newProductArrivalStatus = false;
//         newProductArrivalStatusYes.checked = false;
//     }
// });

async function uploadProduct() {
    // if (newProductArrivalStatusYes.checked) {
    //     newProductArrivalStatus = true;
    //     newProductArrivalStatusNo.checked = false;
    // }
    // else if (newProductArrivalStatusNo.checked) {
    //     newProductArrivalStatus = false;
    // }


    document.querySelector('#uploadProductButton').disabled = true;
    document.querySelector('#uploadProductButton').textContent = 'Uploading ...';
    const productId = generateUniqueProductId();
    // console.log(productId);
    const productName = document.getElementById('productName').value;
    // const productColor = document.getElementById('productColor').value;
    // const productSize = document.getElementById('productSize').value;
    // const productQuantity = document.getElementById('productQuantity').value;
    const productPrice = document.getElementById('productPrice').value;
    const fileInput = document.getElementById('productImage');
    const manufacturerOption = document.getElementById('manufacturer-dropdown').options[document.getElementById('manufacturer-dropdown').selectedIndex];
    const categoryOption = document.getElementById('categoryDropdown').options[document.getElementById('categoryDropdown').selectedIndex];
    console.log(manufacturerOption);
    console.log(categoryOption)
    // const colorShadeOption = document.getElementById('colorShadeDropdown').options[document.getElementById('colorShadeDropdown').selectedIndex];
    // const productSizeOption = document.getElementById('productSizeDropdown').options[document.getElementById('productSizeDropdown').selectedIndex];
    const productDescriptionTextarea = document.querySelector('#product-description');
    const productDetailsTextarea = document.querySelector('#product-details');
    const productSpecificationsTextarea = document.querySelector('#product-specifications')
    const selectedFile = fileInput.files[0];
    console.log(selectedColorIds);
    console.log(selectedSizeIds)

    if (productName && productPrice && manufacturerOption && categoryOption
         && selectedFile && productDescriptionTextarea && productDetailsTextarea
        && productSpecificationsTextarea && selectedColorIds.length!==0 && selectedSizeIds.length !==0
         ) {
        // console.log(newProductArrivalStatus);
        // const fileName = selectedFile.name;
        const fileName = `${productId}/${selectedFile.name}`;
        // console.log(fileName);
        const folderRef = ref(storage, 'product-images');
        const imageRef = ref(folderRef, fileName);

        // Upload the image to Firebase Storage
        uploadBytes(imageRef, selectedFile)
            .then(async (snapshot) => {
                // Get the download URL of the uploaded image
                getDownloadURL(imageRef)
                    .then(async (downloadURL) => {
                        let productData = ''
                            productData = {
                                productId: productId,
                                name: productName,
                                // color: selectedColors,
                                // size: productSize,
                                // quantity: productQuantity,
                                price: parseFloat(productPrice),
                                imageUrl: downloadURL,
                                manufacturerName: manufacturerOption.value,
                                manufacturerId: manufacturerOption.getAttribute('data-id'),
                                categoryName: categoryOption.value,
                                categoryId: categoryOption.getAttribute('data-id'),
                                colorIds :selectedColorIds,
                                sizeIds : selectedSizeIds,
                                // colorShadeName: colorShadeOption.value,
                                // colorShadeId: colorShadeOption.getAttribute('data-id'),
                                // size:productSizeOption.value,
                                // sizeId:productSizeOption.getAttribute('data-id'),
                                ProductDescription: productDescriptionTextarea.value,
                                productDetails:productDetailsTextarea.value,
                                productSpecifications:productSpecificationsTextarea.value,
                                // newProductArrivalStatus:newProductArrivalStatus
                            };
                        console.log(productData);
                        // const manufacturerRef = collection(firestore,'manufacturers');
                        // const manufacturerSnapshot = await getDocs(query(manufacturerRef),where('name','==',manufacturerOption.value));
                        // if(manufacturerSnapshot.empty){
                        //     displayMessage('Manufacturer not found!', 'danger');
                        //     return;
                        // }
                        // const manufacturerDocId = manufacturerSnapshot.docs[0].data().manufacturerId;
                        // console.log(manufacturerDocId)
                        const productCollectionRef = collection(firestore,'products');

                        const productDocRef =await addDoc(productCollectionRef, productData);
                           await updateDoc(productDocRef,{productId:productDocRef.id})
                            .then(() => {
                                displayMessage('Product Uploaded Successfully!', 'success')
                                // clearSelectedColors();

                                document.querySelector('#uploadProductButton').disabled = false;
                                document.querySelector('#uploadProductButton').textContent = 'Upload Product';
                                document.getElementById('productInfoForm').reset();
                            })
                            .catch((error) => {
                                document.querySelector('#uploadProductButton').disabled = false;
                                document.querySelector('#uploadProductButton').textContent = 'Upload Product';
                                console.error('Error adding product information to Firestore:', error);
                            });
                    })
                    .catch((error) => {
                        document.querySelector('#uploadProductButton').disabled = false;
                        document.querySelector('#uploadProductButton').textContent = 'Upload Product';
                        console.error('Error getting image download URL:', error);
                    });
            })
            .catch((error) => {
                document.querySelector('#uploadProductButton').disabled = false;
                document.querySelector('#uploadProductButton').textContent = 'Upload Product';
                console.error('Error uploading image: ', error);
            });
    } else {
        displayMessage('Please fill in all product information and select an image.', 'danger')

        document.querySelector('#uploadProductButton').disabled = false;
        document.querySelector('#uploadProductButton').textContent = 'Upload Product';
        // alert('Please fill in all product information and select an image.');
    }
}

//-------------------------------- Membership id ---------------------------------------

//Generate unique membershipId
function generateUniqueMembershipId() {
    const currentDate = new Date();
    const formattedDate = formatDate(currentDate);
    const formattedTime = formatTime(currentDate);

    // Generate a random alphanumeric string
    const randomString = generateRandomString(6);

    // Combine date, time, and random string to create the unique ID
    const membershipId = `${formattedDate}${formattedTime}${randomString}`;
    return membershipId;
}

function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
}

function formatTime(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}${minutes}${seconds}`;
}

function generateRandomString(length) {
    const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        result += charset.charAt(randomIndex);
    }
    return result;
}

//--------------------------------- GenerateUniqueProdcutId ---------------------------

//Unique productId
function generateUniqueProductId() {
    const timestamp = new Date().getTime();
    const randomPart = Math.random().toString(36).substring(2, 10);
    return `${timestamp}_${randomPart}`;
}

function editProduct() {
    // Redirect to product-edit.html with the product ID as a query parameter
    window.location.href = 'product-edit.html';
}

//--------------------------------- toast message ------------------------------------

//display message function
/**
 * 
 * @param {*} message 
 * @param {*} type 
 * 
 * Toast message
 */
function displayMessage(message, type) {
    // Get the toast container element
    const toastContainer = document.querySelector(".toast-container");

    // Create a clone of the toast template
    const toast = document.querySelector(".toast").cloneNode(true);

    // console.log(toast)
    // Set the success message
    toast.querySelector(".compare-note").innerHTML = message;

    //set text type  success/danger
    if (type === "danger") {
        toast.classList.remove("bg-success");
        toast.classList.add("bg-danger");
    } else {
        toast.classList.add("bg-success");
        toast.classList.remove("bg-danger");
    }

    // Append the toast to the container
    toastContainer.appendChild(toast);

    // Initialize the Bootstrap toast and show it
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();

    // Remove the toast after it's closed
    toast.addEventListener("hidden.bs.toast", function () {
        toast.remove();
    });
}

//---------------------------------------------------------------------------

/**
 * 
 * @returns promise
 */
async function fetchNavCategories() {
    const categoryList = document.querySelector('.nav-category')
    const mobileCategoryList = document.querySelector('.mobile-nav-category')

    categoryList.innerHTML = `
    <div class='w-100 d-flex justify-content-center'>
        <div class="spinner-grow text-secondary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    `
    mobileCategoryList.innerHTML = `
    <div class='w-100 d-flex justify-content-center'>
        <div class="spinner-grow text-secondary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    `
    const categorySnapshot = await getDocs(collection(firestore, 'categories'))
    if (categorySnapshot.empty) {
        console.log('from empty')
        resolve()
        return
    }

    categoryList.innerHTML = ``
    mobileCategoryList.innerHTML = ``

    categorySnapshot.forEach(doc => {
        const span = document.createElement('span')
        span.innerHTML = `
        <div class="gi-tab-list nav flex-column nav-pills me-3" id="v-pills-tab"
        role="tablist" aria-orientation="vertical">
            <button class="nav-link" id="v-pills-home-tab" data-bs-toggle="pill"
                data-bs-target="#v-pills-home" type="button" role="tab"
                aria-controls="v-pills-home" aria-selected="true"><a class="text-decoration-none text-black" href="products.html?categoryId=${doc.data().categoryId}">${doc.data().name}</a>
            </button>
        </div>
        `
        categoryList.appendChild(span)

        const list = document.createElement('li')
        list.innerHTML = `
        <a href="javascript:void(0)">${doc.data().name}</a>
        `
        mobileCategoryList.appendChild(list)
    })
}