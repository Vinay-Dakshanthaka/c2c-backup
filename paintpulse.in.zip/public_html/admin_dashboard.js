//Auth
import  {
    auth,
    signOut,
    onAuthStateChanged,
    updatePassword,
    EmailAuthProvider,
    reauthenticateWithCredential,} from './assets/repository/initialize.js'

//firstore
import {
    firestore,
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc,
    setDoc,
    updateDoc,
    onSnapshot,
    addDoc,
    deleteDoc,
    or,
    and,
    limit,
    startAfter,
    endAt,
    orderBy,
    getCountFromServer,
    deleteField
 } from './assets/repository/initialize.js'

//storage
import {
    storage, 
    ref,
    uploadBytes, 
    getDownloadURL,
    } from './assets/repository/initialize.js'

const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
var userData = null;
var loggedIn = false;

// Function to check if the user is logged in
function isUserLoggedIn() {
    return !!auth.currentUser;
}

//--------------------------------------Event Listenser------------------------------------------- 
confirmLogoutBtn.addEventListener("click", () => {
    signOut(auth)
        .then(() => {
            window.location.href = "login.html";
        })
        .catch((error) => {
            console.error("Error during logout:", error);
        });
});

//AddEventListener to loading the Options when we open DropDown
//--------------------------------------------------------------------------------- 
// Function to fetch and display user data
async function fetchAndDisplayUserData() {
    console.log("1")

    const userRole = userData.role
    const usersRef = collection(firestore, 'users');

    // Check if the user has the admin role
    if (userRole === 'ADMIN') {
        getDocs(usersRef)
            .then((querySnapshot) => {
                const userDetails = document.getElementById('userDetailsData');
                querySnapshot.forEach((doc) => {
                    const userData = doc.data();

                    // Create a table row for each user
                    if (!userData.referralCode) {
                        const userRow = createTableRow(userData, doc);
                        userDetails.appendChild(userRow);
                    }
                    else {
                        // createTableRow(userData, doc);
                        // const userRow = createTableRow(userData, doc);
                        // userDetails.appendChild(userRow);
                    }

                });
            })
            .catch((error) => {
                console.error("Error fetching user data:", error);
            });
    }
    else {
    }
}

//Create User Role
function createTableRow(userData, doc) {
    // console.log(userData)
    let membershipStatus=''
    let badgeClass=''
    if(userData.membershipInactiveStatus){
        membershipStatus='Inactive'
        badgeClass='text-bg-secondary'
    }
    else if(userData.membershipPendingStatus){
        membershipStatus='Pending'
        badgeClass='text-bg-danger'
    }

   let userRow = document.createElement('tr');
   if(userData.role==='CUSTOMER' || userData.role==='ADMIN'){
     if(userData.membershipInactiveStatus || userData.membershipPendingStatus){
        userRow.innerHTML = `
                <td>${userData.firstName || ''}</td>
                <td>${userData.lastName || ''}</td>
                <td>${userData.email || ''}</td>
                <td>${userData.phoneNumber || ''}</td>
                <td>${userData.role || ''}</td>
                <td>
                    <a class="btn btn-primary" type="button"
                            href="orderlist.html?userId=${doc.id}">
                        View Orders
                    </a>
                </td>
                `;

                // const viewCustOrdersBtn = userRow.querySelector(".view-cust-orders-btn");
                // viewCustOrdersBtn.addEventListener("click", async (event) => {
                //     const userId = event.target.getAttribute('data-user-id');
                //     // console.log(userId, event.target)
                //     await fetchAndDisplayAllOrders(userId, event.target);
                // });
            } 
        }
        return userRow;
}

//-----------------------------cart dependency----------------------------
//update cart function cart(dependency)
/**
 * 
 * @returns promise
 * 
 * requires: 
 * getCart()
 */
function updateCart() {
    return new Promise(async (resolve) => {
        console.log("from update cart")
        const shownCart = document.querySelector('#shown-cart')

        let cart = await getCart()
        console.log(cart.length)

        if (cart.length) {
            document.querySelectorAll('.cart').forEach(ele => ele.textContent = cart.length)
        }
        else {
            document.querySelectorAll('.cart').forEach(ele => ele.textContent = 0)
        }
        console.log("resolve")
        resolve()
    })
}

async function getCart() {
    return new Promise(async (resolve) => {
        if (loggedIn) {
            const cartSnapshot = await getDocs(collection(firestore, 'users', auth.currentUser.uid, 'cart'))
            if (cartSnapshot.empty) {
                resolve([])
            }
            let cart = []
            cartSnapshot.forEach(doc => {
                cart.push(doc.data())
            })
            resolve(cart)
        }
        else {
            const cartSnapshot = JSON.parse(sessionStorage.getItem('cart'))
            if (!cartSnapshot) {
                resolve([])
                return
            }
            var cart = []
            cartSnapshot.forEach(doc => {
                cart.push(doc)
            })
            resolve(cart)
        }
    })
}

//get user snapshot cart(dependency)
function getUserSnapshot(uid) {
    const userRef = doc(firestore, 'users', uid)
    console.log('3')
    return new Promise((resolve, reject) => {
        resolve(getDoc(userRef))
    })
}

/**
 * Necessary fucntions to call after pageload
 */
async function postPageLoadFunctions(){
    await updateCart();
    fetchAndDisplayUserData();
    // fetchAndDisplayCommissions();
    // await fetchNavCategories();
}

//------------------------------loading and role access-----------------------------
onAuthStateChanged(auth, async (user) => {
    if (user) {
        loggedIn = true
        onLoggedIn();
        document.querySelector('#logout-btn').style.display='block';
        const docRef = doc(firestore, "users", user.uid);
        const docSnap = getDoc(docRef);
        docSnap.then(async (docSnapshot) => {
            if (docSnapshot.exists()) {
                userData = docSnapshot.data();
                roleAccess(userData.role);
                updateProfileName(userData.role,userData.firstName);
                updateProfilePicture(userData.role,userData.profilePicture)
            }
        });
    } else {
        document.querySelector('#logout-btn').style.display='none';
        window.location.href = "login.html";
    }
    await postPageLoadFunctions();
});

function roleAccess(role) {
    const roleMap = new Map([
        ["ADMIN", "adminAppbar"],
        ["CUSTOMER", "customerAppbar"],
        ["AGENT", "agentAppbar"],
    ]);
    const appbarList = document.querySelectorAll(`#${roleMap.get(role)}`);
    appbarList.forEach((appbar) => {
        appbar.classList.remove("d-none");
    })
}

function updateProfileName(role, fullName) {
    console.log(fullName)
    let profileNameElement;
    switch (role) {
        case 'CUSTOMER':
            profileNameElement = document.getElementById('customerAppbar').querySelector('.profile-name');
            break;
        case 'AGENT':
            profileNameElement = document.getElementById('agentAppbar').querySelector('.profile-name');
            break;
        case 'ADMIN':
            profileNameElement = document.getElementById('adminAppbar').querySelector('.profile-name');
            break;
        default:
            console.error('Unknown role:', role);
            return;
    }
    profileNameElement.textContent = fullName;
}

function updateProfilePicture(role, profilePicture) {
    let profilePictureElement;
    const defaultProfilePicture = 'https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp';

    switch (role) {
        case 'CUSTOMER':
            profilePictureElement = document.getElementById('customerAppbar').querySelector('#profile-picture');
            break;
        case 'AGENT':
            profilePictureElement = document.getElementById('agentAppbar').querySelector('#profile-picture');
            break;
        case 'ADMIN':
            profilePictureElement = document.getElementById('adminAppbar').querySelector('#profile-picture');
            break;
        default:
            console.error('Unknown role:', role)
            return;
    }

    // Check if profilePicture is empty or undefined
    if (profilePicture && profilePicture.trim() !== '') {
        profilePictureElement.src = profilePicture;
    } else {
        // Set to the default profile picture if no picture is provided
        profilePictureElement.src = defaultProfilePicture;
    }
}

//to execut upon logging in
function onLoggedIn() {
    var navItemList = document.querySelectorAll(".loggedIn");
    navItemList.forEach((navItem) => {
        navItem.style.display = "block";
    });

    navItemList = document.querySelectorAll(".loggedOut");
    navItemList.forEach((navItem) => {
        navItem.style.display = "none";
    });
}

//to execute upon logging out
function onLoggedOut() {
    var navItemList = document.querySelectorAll(".loggedOut");
    navItemList.forEach((navItem) => {
        navItem.style.display = "block";
    });

    navItemList = document.querySelectorAll(".loggedIn");
    navItemList.forEach((navItem) => {
        navItem.style.display = "none";
    });
}

// Open the subordinates modal when the "isCustomers" button is clicked
function openSubordinatesModal(agentEmail, membershipId) {
    displaySubordinateCustomers(agentEmail, membershipId);
    const subordinatesModal = new bootstrap.Modal(document.getElementById('subordinatesModal'));
    subordinatesModal.show();
}

let totalNumberOfCustomers = 0;
//******************************** Display orders ***********************************************

// Function to display all orders for a customer in the modal
function displayAllOrders(orders) {
    console.log("inside display all orders")
    return new Promise(async (resolve) => {
        orders.sort((a, b) => {
            const dateA = convertToDate(a.date, a.time);
            const dateB = convertToDate(b.date, b.time);
            return new Date(dateB) - new Date(dateA);
        });

        const ordersContainer = document.createElement("div");
        ordersContainer.className = "ordersContainer";
        const orderModalContent = document.getElementById("orderModalContent");

        if (Array.isArray(orders) && orders.length > 0) {
            for (const order of orders) {
                const orderContainer = document.createElement("div");
                orderContainer.className = "order-container";

                // Create and append elements for order ID, date, and time
                const orderInfoContainer = document.createElement("div");
                orderInfoContainer.className = "order-info-container";

                const orderIDElement = document.createElement("div");
                orderIDElement.className = "order-field";
                orderIDElement.innerHTML = `<strong> Order ID:</strong> ${order.orderId} `;

                const orderDateElement = document.createElement("div");
                orderDateElement.className = "order-field";
                orderDateElement.innerHTML = `<strong> Order Date:</strong> ${order.date || ""} `;

                const orderTimeElement = document.createElement("div");
                orderTimeElement.className = "order-field";
                orderTimeElement.innerHTML = `<strong> Order Time:</strong> ${order.time || ""} `;

                orderInfoContainer.appendChild(orderIDElement);
                orderInfoContainer.appendChild(orderDateElement);
                orderInfoContainer.appendChild(orderTimeElement);

                orderContainer.appendChild(orderInfoContainer);

                const orderDetailsContainer = document.createElement("div");
                orderDetailsContainer.className = "order-details";
                orderDetailsContainer.style.display = "none";
                fetchAndDisplayOrderDetails(order, orderDetailsContainer);

                // Append a "View Details" button
                const viewDetailsButton = document.createElement("button");
                viewDetailsButton.className = "btn btn-primary view-details-btn";
                viewDetailsButton.textContent = "View Details";

                viewDetailsButton.addEventListener("click", () => {
                    orderDetailsContainer.style.display = orderDetailsContainer.style.display === "none" ? "block" : "none";
                });

                orderContainer.appendChild(viewDetailsButton);
                orderContainer.appendChild(orderDetailsContainer);

                // Append a horizontal line after each order
                const horizontalLine = document.createElement("hr");
                horizontalLine.className = "impressive-hr";
                orderContainer.appendChild(horizontalLine);

                // Append the order container to the orders container
                ordersContainer.appendChild(orderContainer);
            }

            orderModalContent.innerHTML = "";
            orderModalContent.appendChild(ordersContainer);
        } else {
            orderModalContent.innerHTML = "<p>No orders found for this customer.</p>";
            console.log("1");
        }
        resolve()
    })
}

// Function to convert date and time strings to a Date object
function convertToDate(dateString, timeString) {
    // Split the date and time strings
    const dateParts = dateString.split("/");
    const timeParts = timeString.split(" ");

    // Parse the time parts
    const time = timeParts[0];
    const isPM = timeParts[1] === "pm";

    // Extract hours, minutes, and seconds
    const timeParts2 = time.split(":");
    let hours = parseInt(timeParts2[0]);
    const minutes = parseInt(timeParts2[1]);

    // Convert to 24-hour format if PM
    if (isPM && hours !== 12) {
        hours += 12;
    } else if (!isPM && hours === 12) {
        hours = 0;
    }

    // Format the time as HH:mm for proper sorting
    const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return `${dateParts[2]}-${dateParts[1]}-${dateParts[0]} ${formattedTime}`;
}

// Function to fetch and display order details for a specific order
async function fetchAndDisplayOrderDetails(order, orderDetailsContainer) {
    try {
        // const orderDetails = await fetchOrderDetailsByOrderId(orderId);

        if (order) {
            // Create HTML to display order details
            const orderDetailsHTML = `
                        <div class="order-field">
                            <strong>Order State:</strong> ${order.state || ""}
                        </div>
                        <div class="order-field">
                            <strong>Payment Method:</strong> ${order.paymentMethod || ""}
                        </div>
                        <div class="order-field">
                            <strong>Shipping Address:</strong> <pre>${order.address || ""}</pre>
                        </div>
                        <div class="order-field ${order.summary.referralId ? '' : 'd-none'}">
                            <strong>Referral Id:</strong> <pre>${order.summary.referralId || ""}</pre>
                        </div>
                        <h3>Items Purchased</h3>
                        <ul>
                            ${order.summary.items && Array.isArray(order.summary.items)
                    ? order.summary.items.map((item) => `
                                    <li>
                                        <strong>Product ID:</strong> ${item.productId || ""}<br>
                                        <strong>Product Name:</strong> ${item.productName || ""}<br>
                                        <strong>Product Category:</strong> ${item.productCategory || ""}<br>
                                        <strong>Product Color:</strong> ${item.productColor || ""}<br>
                                        <strong>Product Color Shade:</strong> ${item.productColorShade || ""}<br>
                                        <strong>Product Size:</strong> ${item.productSize || ""} Ltrs. <br>
                                        <strong>Product Price:</strong> Rs. ${item.productPrice || ""}<br>
                                        <strong>Product Quantity:</strong> ${item.productQuantity || ""} No's
                                    </li><br>`
                    ).join('')
                    : "<li>No items found</li>"
                }
                        </ul>
                        <h3>Bill Summary</h3>
                        <div class="order-field">
                            <strong>Subtotal:</strong> Rs. ${order.summary.billSummary.subTotal || ""}
                        </div>
                        <div class="order-field ${order.calculatedCommission ? '' : 'd-none'}">
                            <strong>Calculated commission :</strong> Rs. ${order.calculatedCommission || ""}
                        </div>
                        <div class="order-field">
                            <strong>Delivery Fee:</strong> Rs. ${order.summary.billSummary.deliveryFee || ""}
                        </div>
                        <div class="order-field">
                            <strong>Grand Total:</strong> Rs. ${order.summary.billSummary.grandTotal || ""}
                        </div><br>
                    `;
            // Set the HTML content of the order details container
            orderDetailsContainer.innerHTML = orderDetailsHTML;
            console.log("2");
        } else {
            // Handle the case where order details are not found
        }
    } catch (error) {
        console.error("Error fetching order details:", error);
    }
}

//********************* Display Subordinate*************************************

async function displaySubordinateCustomers(agentEmail, membershipId) {
    // const usersRef = 
    const subordinateTableBody = document.getElementById('subordinateTableBody');
    subordinateTableBody.innerHTML = ''; // Clear the table body before adding new data

    // Reset the total number of customers
    totalNumberOfCustomers = 0;
    try {
        const querySnapshot = await getDocs(collection(firestore, 'users'));
        const commissions = [];

        const promises = querySnapshot.docs.map(async (doc) => {
            const customersData = doc.data();
            if (customersData.role === "CUSTOMER" && customersData.referralCode === membershipId &&
                customersData.email != agentEmail) {
                const totalOrders = await fetchOrdersForUser(doc.id);
                const totalCommission = await fetchTotalCommissionForUser(doc.id);
                // console.log(totalCommission);
                commissions.push(totalCommission);

                const subordinateRow = document.createElement('tr');
                subordinateRow.innerHTML = `
                            <td>${customersData.firstName || ''} ${customersData.lastName || ''}</td>
                            <td>${customersData.email || ''}</td>
                            <td>${customersData.phoneNumber || ''}</td>
                            <td>${customersData.role || ''}</td>
                            <td>
                                <button class="btn btn-primary view-orders-btn"
                                        data-bs-toggle="modal"
                                        data-bs-target="#orderModal"
                                        data-user-id="${doc.id}">
                                    View Orders
                                </button>
                            </td>
                            <td>${totalOrders.length || '0'}</td>
                            <td>${totalCommission}</td>
                        `;
                subordinateTableBody.appendChild(subordinateRow);

                const viewOrdersBtn = subordinateRow.querySelector(".view-orders-btn");
                viewOrdersBtn.addEventListener("click", async (event) => {
                    const userId = event.target.getAttribute('data-user-id');
                    // console.log(event.target.disabled);
                    await fetchAndDisplayAllOrders(userId, event.target);
                });
            }
        });
        await Promise.all(promises);

        // Calculate total commission by summing up individual commissions
        const grandTotalCommission = commissions.reduce((acc, commission) => acc + commission, 0);
        console.log(grandTotalCommission);

        const totalCommissionContainer = document.getElementById('totalCommissionContainer');
        totalCommissionContainer.innerHTML = `<strong>Grand Total of All Commissions:</strong> Rs. ${grandTotalCommission}`;
    } catch (error) {
        console.error('Error fetching subordinate customers:', error);
    }
}

// Function to fetch and display all orders of a customer
async function fetchAndDisplayAllOrders(userId, orderBtn) {
    console.log("1")
    orderBtn.disabled = true
    orderBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                    <span role="status">fetching orders...</span>
                `
    const orders = await fetchOrdersForUser(userId);
    console.log("2")
    if (Array.isArray(orders) && orders.length > 0) {
        console.log("3")
        const orderDetailsList = [];

        const orderIds = []
        //loop get the ids
        orders.forEach(async (order) => {
            orderIds.push(order.orderId)
        })
        const orderSnapshot = await getDocs(query(collection(firestore, 'orders'), where('orderId', 'in', orderIds)))
        //return if empty
        console.log("1")
        if (orderSnapshot.empty) {
            const orderModalContent = document.getElementById("orderModalContent");
            orderModalContent.innerHTML = "<p>No orders found for this customer.</p>";
            orderBtn.disabled = false
            orderBtn.innerHTML = `View orders`
            return
        }
        //push all json data in one list
        orderSnapshot.forEach(doc => {
            orderDetailsList.push(doc.data())
        })

        console.log(orderDetailsList);
        // Display all order details in the modal
        await displayAllOrders(orderDetailsList);
        orderBtn.disabled = false
        orderBtn.innerHTML = `View orders`
    } else {
        console.log("4")
        // Handle the case where there are no orders for the customer
        orderBtn.disabled = false
        orderBtn.innerHTML = `View orders`
        displayAllOrders([]);
    }
}

// Function to fetch orders for a specific user
async function fetchOrdersForUser(userId) {
    const userRef = doc(firestore, "users", userId);
    const ordersRef = collection(userRef, "orders");

    try {
        const querySnapshot = await getDocs(ordersRef);
        const orders = [];

        if (!querySnapshot.empty) {
            querySnapshot.forEach((doc) => {
                const orderData = doc.data();
                // console.log(orderData);
                orders.push(orderData);
            });
        }

        return orders;
    } catch (error) {
        console.error("Error fetching orders for user:", error);
        return [];
    }
}

async function fetchTotalCommissionForUser(userId) {
    const orders = await fetchOrdersForUser(userId);
    var orderDetailsList = [];
    if (Array.isArray(orders) && orders.length > 0) {
        const orderIds = []
        orders.forEach(async (order) => {
            orderIds.push(order.orderId)
        })
        const orderSnapshot = await getDocs(query(collection(firestore, 'orders'), where('orderId', 'in', orderIds)))
        if (orderSnapshot.empty) return
        orderSnapshot.forEach(doc => {
            orderDetailsList.push(doc.data())
        });
    }

    console.log(orderDetailsList);
    if (!orderDetailsList || orderDetailsList.length === 0) {
        return 0;
    }
    const totalCommissions = orderDetailsList.reduce((sum, orderDetailsList) => sum + parseFloat(orderDetailsList.calculatedCommission || 0), 0);
    return totalCommissions;
}

// ---------------------------- Update role--------------------------------------
var emailInput = document.getElementById('email');
var newRoleInput = document.getElementById('new-role');
var membershipIdDisplay=document.querySelector('.member-id-display')
console.log(newRoleInput)
var membershipIdInput=document.querySelector('.member-id-input')
newRoleInput.addEventListener('change',function(){
    console.log(this.value)
    if(this.value==='AGENT'){
        membershipIdDisplay.classList.remove('d-none')
    }
    else{
       membershipIdDisplay.classList.add('d-none')
    }   
})

async function openUpdateRoleModal(email, userRole) {
    emailInput.value = email;
    newRoleInput.value = userRole;

    const updateRoleForm = document.getElementById('updateRoleForm');
    const isListenerAttached = updateRoleForm.getAttribute('data-listener-attached');
    console.log(isListenerAttached);
    if (!isListenerAttached) {
        updateRoleForm.addEventListener('submit', handleUpdateRoleSubmit);
        updateRoleForm.setAttribute('data-listener-attached', 'true');
    }

    async function handleUpdateRoleSubmit(e) {
        e.preventDefault();
        document.querySelector('#formSubmitButton').disabled = true
        document.querySelector('#formSubmitButton').textContent = 'Saving...'
        const newRole = newRoleInput.value;
        const userEmail = emailInput.value;
        const membershipIdValue=membershipIdInput.value;
        if (newRole === 'AGENT' && userEmail && membershipIdValue) {
            const usersRef = collection(firestore, 'users');
            const queryRef = query(usersRef, where("email", "==", userEmail));

            let membershipId = null;
            getDocs(queryRef)
                .then(async(querySnapshot) => {
                    if (!querySnapshot.empty) {
                        const userDoc = querySnapshot.docs[0];
                        console.log(membershipIdValue);

                        const updateData = {
                            role: newRole,
                            membershipId:membershipIdValue,
                            membershipInactiveStatus:false,
                            membershipPendingStatus:false,
                            membershipActiveStatus:true,
                            referredStatus: deleteField()
                             };
                        if (membershipId) {
                            updateData.membershipId = membershipId;
                        }

                        updateDoc(userDoc.ref, updateData)
                            .then(async() => {
                                console.log("promotion")
                                displayMessage(`User's role updated to ${newRole} successfully.`, 'success')
                                await membershipAgentlist();
                                await fetchAndDisplayUserData();
                                document.querySelector('#userDetailsData').innerHTML = ""
                                document.querySelector('#formSubmitButton').disabled = false
                                document.querySelector('#formSubmitButton').textContent = 'Save changes'
                            })
                            .catch((error) => {
                                console.error("Error updating user role:", error);
                            });
                    }
                    else {
                        document.querySelector('#formSubmitButton').disabled = false
                        document.querySelector('#formSubmitButton').textContent = 'Save changes'
                        alert(`User with email ${userEmail} not found.`);
                    }
                })
                .catch((error) => {
                    console.error("Error fetching user data:", error);
                });
        }
        else {
            const usersRef = collection(firestore, 'users');
            const queryRef = query(usersRef, where("email", "==", userEmail));
            getDocs(queryRef)
                .then(async(querySnapshot) => {
                    if (!querySnapshot.empty) {
                        const userDoc = querySnapshot.docs[0];
                        const userData = userDoc.data();
                        if (userData.membershipId) {
                            // Update the user document to set membershipId to null
                            updateDoc(userDoc.ref, 
                                { 
                                    role: newRole,
                                     membershipId: deleteField(),
                                     membershipInactiveStatus:false,
                                     membershipPendingStatus:false,
                                     membershipActiveStatus:true,
                                      referredStatus: false
                                 })
                                .then(async() => {
                                    console.log("demotion");
                                    displayMessage(`User's role updated to ${newRole} successfully.`, 'success');
                                    document.querySelector('#userDetailsData').innerHTML = '';
                                    document.querySelector('#formSubmitButton').disabled = false;
                                    document.querySelector('#formSubmitButton').textContent = 'Save changes';
                                    await fetchAndDisplayUserData();
                                    await membershipAgentlist();
                                })
                                .catch((error) => {
                                    console.error("Error updating user role:", error);
                                });
                        }
                        else {
                            console.log("User does not have a membershipId");
                        }
                    }
                    else {
                        console.log("User document does not exist");
                    }
                })
                .catch((error) => {
                    console.error("Error fetching user data:", error);
                });
        }
    }
}

//------------------------------Upload Product--------------------------------------
// async function addManufacturer(manufacturerName) {
//     try {
//         const manufacturerRef = collection(firestore, 'manufacturers');
//         const docRef = await addDoc(manufacturerRef, { name: manufacturerName });
//         await updateDoc(docRef, { manufacturerId: docRef.id })
//         document.querySelector('#manufacturerDropdown').addEventListener('click', fetchManufacturers)
//         return docRef.id;
//     } catch (error) {
//         console.error('Error adding manufacturer:', error);
//         throw error;
//     }
// }

// Add a new Category
// async function addCategory(categoryName) {
//     try {
//         const categoryRef = collection(firestore, 'categories');
//         const docRef = await addDoc(categoryRef, { name: categoryName });
//         await updateDoc(docRef, { categoryId: docRef.id })
//         document.querySelector('#categoryDropdown').addEventListener('click', fetchCategories)
//         return docRef.id;
//     } catch (error) {
//         console.error('Error adding category:', error);
//         throw error;
//     }
// }

// Function to edit a manufacturer
// async function editManufacturer(manufacturerId, manufacturerName) {
//     console.log(manufacturerId)
//     console.log('from editmanufacturer')
//     const updatedManufacturerName = prompt('Edit Manufacturer Name:', manufacturerName);
//     if (updatedManufacturerName !== null) {
//         const manufacturerCollection = collection(firestore, 'manufacturers')
//         const manufacturerSnapshot = await getDocs(query(manufacturerCollection, where('manufacturerId', '==', manufacturerId)))
//         if (!manufacturerSnapshot.empty) {
//             console.log(manufacturerSnapshot.docs[0].data())
//             updateDoc(manufacturerSnapshot.docs[0].ref, { name: updatedManufacturerName })
//                 .then(() => {
//                     console.log(`Successfully Updated to ${updatedManufacturerName}`)
//                     console.log('Manufacturer updated successfully');
//                     displayMessage('Manufacturer updated successfully!', 'success');
//                     document.querySelector('#manufacturerDropdown').addEventListener('click', fetchManufacturers)
//                     populateManufacturerList();
//                 })
//                 .catch((error) => {
//                     console.error('Error updating manufacturer:', error);
//                 });
//         }
//     }
// }

// Function to delete a manufacturer
// async function deleteManufacturer(manufacturerId) {
//     const confirmation = confirm('Are you sure you want to delete this manufacturer?');
//     if (confirmation) {
//         try {
//             const manufacturerCollection = collection(firestore, 'manufacturers')
//             const manufacturerSnapshot = await getDocs(query(manufacturerCollection, where('manufacturerId', '==', manufacturerId)))
//             if (!manufacturerSnapshot.empty) {
//                 await deleteDoc(manufacturerSnapshot.docs[0].ref)
//             }
//             console.log('Manufacturer deleted successfully');
//             displayMessage('Manufacturer deleted successfully!', 'success');
//             document.querySelector('#manufacturerDropdown').addEventListener('click', fetchManufacturers)
//             populateManufacturerList();
//         } catch (error) {
//             console.error('Error deleting manufacturer:', error);
//         }
//     }
// }

// Function to edit a category
// async function editCategory(categoryId, categoryName) {
//     const updatedCategoryName = prompt('Edit Category Name:', categoryName);
//     if (updatedCategoryName !== null) {
//         const categoryCollection = collection(firestore, 'categories')
//         const categorySnapshot = await getDocs(query(categoryCollection, where('categoryId', '==', categoryId)))
//         if (!categorySnapshot.empty) {
//             updateDoc(categorySnapshot.docs[0].ref, { name: updatedCategoryName })
//                 .then(() => {
//                     console.log('Category updated successfully');
//                     displayMessage('Category updated successfully!', 'success');
//                     document.querySelector('#categoryDropdown').addEventListener('click', fetchCategories)
//                     populateCategoryList();
//                 })
//                 .catch((error) => {
//                     console.error('Error updating category:', error);
//                 });
//         }
//     }
// }

// async function deleteCategory(categoryId) {
//     const confirmation = confirm('Are you sure you want to delete this category?');
//     if (confirmation) {
//         try {
//             const categoryCollection = collection(firestore, 'categories')
//             const categorySnapshot = await getDocs(query(categoryCollection, where('categoryId', '==', categoryId)))
//             if (!categorySnapshot.empty) {
//                 await deleteDoc(categorySnapshot.docs[0].ref);
//             }
//             console.log('Category deleted successfully');
//             displayMessage('Category deleted successfully!', 'success');
//             document.querySelector('#categoryDropdown').addEventListener('click', fetchCategories)
//             populateCategoryList();
//         } catch (error) {
//             console.error('Error deleting category:', error);
//         }
//     }
// }

// async function fetchManufacturers() {
//     const select = document.querySelector('#manufacturerDropdown')
//     select.innerHTML = `<option value="">
//                                 Loading ...
//                             </option>`
//     const manufacturerSnapshot = await getDocs(collection(firestore, 'manufacturers'))
//     if (!manufacturerSnapshot.empty) {
//         select.removeEventListener('click', fetchManufacturers)
//         select.innerHTML = ``
//         const option = document.createElement('option')
//         option.innerHTML = `Please select`
//         select.appendChild(option)
//         manufacturerSnapshot.forEach(doc => {
//             const option = document.createElement('option')
//             option.setAttribute('value', doc.data().name)
//             option.setAttribute('data-id', doc.data().manufacturerId)
//             option.innerHTML = `${doc.data().name}`
//             select.appendChild(option)
//         })
//         // document.querySelector('#colorShadeDropdown').click()
//     }
//     else {
//         select.innerHTML = `<option value="">Please select</option>`
//         displayMessage('No manufactures added!', 'danger')
//     }
// }

// async function fetchCategories() {
//     const select = document.querySelector('#categoryDropdown')
//     select.innerHTML = `<option value="">
//                                 Loading ...
//                             </option>`
//     const categorySnapshot = await getDocs(collection(firestore, 'categories'))
//     if (!categorySnapshot.empty) {
//         select.removeEventListener('click', fetchCategories)
//         select.innerHTML = ``
//         const option = document.createElement('option')
//         option.innerHTML = `Please select`
//         select.appendChild(option)
//         categorySnapshot.forEach(doc => {
//             const option = document.createElement('option')
//             option.setAttribute('value', doc.data().name)
//             option.setAttribute('data-id', doc.data().categoryId)
//             option.innerHTML = `${doc.data().name}`
//             select.appendChild(option)
//         })
//     }
//     else {
//         select.innerHTML = `<option value="">Please select</option>`
//         displayMessage('No categories added!', 'danger')
//     }
// }

// Add a click event listener to open the manufacturer modal
// const openManufacturerModalButton = document.getElementById('addManufacturerButton');
// openManufacturerModalButton.addEventListener('click', () => {
//     document.getElementById('manufacturerName').value = '';
//     populateManufacturerList();
// });

// Add a click event listener to open the category modal
// const openCategoryModalButton = document.getElementById('addCategoryButton');
// openCategoryModalButton.addEventListener('click', () => {
//     console.log('from addBtn')
//     document.getElementById('categoryName').value = '';
//     populateCategoryList();
// });

// Populate Manufacturer List
// function populateManufacturerList() {
//     const manufacturerList = document.getElementById('manufacturerList');
//     getDocs(collection(firestore, 'manufacturers'))
//         .then((manufacturers) => {
//             manufacturerList.innerHTML = '';
//             manufacturers.forEach((manufacturerDoc) => {
//                 const manufacturer = manufacturerDoc.data();
//                 const row = document.createElement('tr');
//                 row.innerHTML = `
//                                 <td>${manufacturer.name}</td>
//                                 <td>
//                                     <button class="btn btn-sm btn-primary edit">Edit</button>
//                                     <button class="btn btn-sm btn-danger delete" >Delete</button>
//                                 </td>
//                             `;
//                 manufacturerList.appendChild(row);
//                 row.querySelector('.edit').addEventListener('click', () => editManufacturer(manufacturer.manufacturerId, manufacturer.name))
//                 row.querySelector('.delete').addEventListener('click', () => deleteManufacturer(manufacturer.manufacturerId))
//             });
//         })
//         .catch((error) => {
//             console.error('Error getting manufacturers:', error);
//         });
// }

// Populate Category List
// function populateCategoryList() {
//     const categoryList = document.getElementById('categoryList');
//     getDocs(collection(firestore, 'categories'))
//         .then((categories) => {
//             categoryList.innerHTML = '';
//             categories.forEach((categoryDoc) => {
//                 const category = categoryDoc.data();
//                 const row = document.createElement('tr');
//                 row.innerHTML = `
//                     <td>${category.name}</td>
//                     <td>
//                         <button class="btn btn-sm btn-primary edit">Edit</button>
//                         <button class="btn btn-sm btn-danger delete">Delete</button>
//                     </td>
//                 `;
//                 categoryList.appendChild(row);
//                 row.querySelector('.edit').addEventListener('click', () => editCategory(category.categoryId, category.name))
//                 row.querySelector('.delete').addEventListener('click', () => deleteCategory(category.categoryId))
//             });
//         })
//         .catch((error) => {
//             console.error('Error getting categories:', error);
//         });
// }

// Add Manufacturer
// document.getElementById('saveManufacturerButton').addEventListener('click', async () => {
//     const manufacturerName = document.getElementById('manufacturerName').value;
//     if (manufacturerName) {
//         try {
//             const manufacturerId = await addManufacturer(manufacturerName);
//             console.log('Manufacturer added successfully');
//             displayMessage('Manufacturer added successfully!', 'success');
//             populateManufacturerList();
//             document.getElementById('manufacturerName').value = '';
//         } catch (error) {
//             console.error('Error adding manufacturer:', error);
//         }
//     }
// });

// Add Category
// document.getElementById('saveCategoryButton').addEventListener('click', async () => {
//     const categoryName = document.getElementById('categoryName').value;
//     if (categoryName) {
//         try {
//             const categoryId = await addCategory(categoryName);
//             console.log('Category added successfully');
//             displayMessage('Category added successfully!', 'success');
//             populateCategoryList();
//             document.getElementById('categoryName').value = '';
//         } catch (error) {
//             console.error('Error adding category:', error);
//         }
//     }
// });

//------------------------------- Color Shades of Products-------------------------
// async function addColorShade(manufacturerId, colorShadeName) {
//     try {
//         const colorShadeRef = collection(firestore, 'colorShades');
//         const docRef = await addDoc(colorShadeRef, { name: colorShadeName, manufacturerId });
//         await updateDoc(docRef, { colorShadeId: docRef.id });
//         // document.querySelector('#colorShadeDropdown').addEventListener('click', fetchColorShades);
//         return docRef.id;
//     } catch (error) {
//         console.error('Error adding color shade:', error);
//         throw error;
//     }
// }

// async function fetchColorShades() {
//     const manufacturerId = document.querySelector('#manufacturerDropdown').options[document.querySelector('#manufacturerDropdown').selectedIndex].getAttribute('data-id')
//     if (!manufacturerId) {
//         displayMessage('Please select a manufacturer!', 'danger')
//         return
//     }
//     console.log(manufacturerId)
//     const select = document.querySelector(`#colorShadeDropdown`);
//     select.innerHTML = `<option value="">
//                     Loading ...
//                 </option>`;
//     const colorShadeSnapshot = await getDocs(query(collection(firestore, 'colorShades'), where('manufacturerId', '==', manufacturerId)));
//     if (!colorShadeSnapshot.empty) {
//         select.removeEventListener('click', fetchColorShades);
//         select.innerHTML = '';
//         const option = document.createElement('option');
//         option.innerHTML = 'Please select';
//         select.appendChild(option);
//         colorShadeSnapshot.forEach(doc => {
//             const option = document.createElement('option');
//             option.setAttribute('value', doc.data().name);
//             option.setAttribute('data-id', doc.data().colorShadeId);
//             option.innerHTML = `${doc.data().name}`;
//             select.appendChild(option);
//         });
//     } else {
//         select.innerHTML = `<option value="">Please select</option>`;
//         displayMessage('No color shades added for this manufacturer!', 'danger');
//     }
// }


//Update ColorShades
// async function editColorShade(colorShadeId, colorShadeName) {
//     const updatedColorShadeName = prompt('Edit Color Shade Name:', colorShadeName);
//     if (updatedColorShadeName !== null) {
//         const colorShadeCollection = collection(firestore, 'colorShades');
//         const colorShadeSnapshot = await getDocs(query(colorShadeCollection, where('colorShadeId', '==', colorShadeId)));
//         if (!colorShadeSnapshot.empty) {
//             updateDoc(colorShadeSnapshot.docs[0].ref, { name: updatedColorShadeName })
//                 .then(() => {
//                     console.log('Color Shade updated successfully');
//                     displayMessage('Color Shade updated successfully!', 'success');
//                     document.querySelector('#colorShadeDropdown').addEventListener('click', fetchColorShades)
//                     document.querySelector('#colorShadeManufacturer').dispatchEvent(new Event('change'));
//                 })
//                 .catch((error) => {
//                     console.error('Error updating color shade:', error);
//                 });
//         }
//     }
// }

//Delete ColorShades
// async function deleteColorShade(colorShadeId) {
//     const confirmation = confirm('Are you sure you want to delete this color shade?');
//     if (confirmation) {
//         try {
//             const colorShadesCollection = collection(firestore, 'colorShades');
//             const colorShadeSnapshot = await getDocs(query(colorShadesCollection, where('colorShadeId', '==', colorShadeId)));
//             if (!colorShadeSnapshot.empty) {
//                 await deleteDoc(colorShadeSnapshot.docs[0].ref);
//             }
//             console.log('Color shade deleted successfully');
//             displayMessage('Color shade deleted successfully!', 'success');
//             document.querySelector('#colorShadeDropdown').addEventListener('click', fetchColorShades)
//             document.querySelector('#colorShadeManufacturer').dispatchEvent(new Event('change'));
//         } catch (error) {
//             console.error('Error deleting color shade:', error);
//         }
//     }
// }

// Function to populate color shades list in the modal
// async function populateColorShadeList(event) {
//     const colorShadeList = document.getElementById('colorShadeList');
//     if (!event) {
//         colorShadeList.innerHTML = `<tr><td>Please select a manufacturer.</td><td></td></tr>`;
//         return
//     }
//     const manufacturerId = event.target.options[event.target.selectedIndex].value
//     console.log(manufacturerId)
//     colorShadeList.innerHTML = `<tr><td>Loading...</td><td></td></tr>`;

//     try {
//         const colorShadeSnapshot = await getDocs(query(collection(firestore, 'colorShades'), where('manufacturerId', '==', manufacturerId)));
//         colorShadeList.innerHTML = ''; // Clear the list

//         if (!colorShadeSnapshot.empty) {
//             colorShadeSnapshot.forEach(doc => {
//                 const colorShade = doc.data();
//                 console.log(colorShade);
//                 const row = document.createElement('tr');
//                 row.innerHTML = `
//                                 <td>${colorShade.name}</td>
//                                 <td>
//                                     <button class="btn btn-sm btn-primary edit">Edit</button>
//                                     <button class="btn btn-sm btn-danger delete">Delete</button>
//                                 </td>
//                             `;
//                 colorShadeList.appendChild(row);

//                 // Add event listeners for edit and delete buttons
//                 row.querySelector('.edit').addEventListener('click', () => editColorShade(colorShade.colorShadeId, colorShade.name));
//                 row.querySelector('.delete').addEventListener('click', () => deleteColorShade(colorShade.colorShadeId));
//             });
//         } else {
//             colorShadeList.innerHTML = `<tr><td>No color shades added yet.</td><td></td></tr>`;
//         }
//     } catch (error) {
//         console.error('Error getting color shades:', error);
//         colorShadeList.innerHTML = `<tr><td>Error loading color shades.</td><td></td></tr>`;
//     }
// }

// Open Color Shade Modal
// const openColorShadeModalButton = document.getElementById('addColorShadeButton');
// openColorShadeModalButton.addEventListener('click', () => {
//     // Clear the color shade form
//     document.getElementById('colorShadeName').value = '';
//     // Fetch and populate the manufacturers list in the modal
//     populateManufacturerDropdown('colorShadeManufacturer');
//     populateColorShadeList(null)
//     // Fetch and populate the color shades list in the modal
//     const selectedManufacturerId = document.getElementById('colorShadeManufacturer').value;
//     // fetchColorShades(selectedManufacturerId, 'colorShadeDropdown')
// });

// Function to populate the manufacturer dropdown in the modal
// function populateManufacturerDropdown(targetDropdownId) {
//     const select = document.querySelector(`#${targetDropdownId}`);
//     select.innerHTML = `<option value="">
//                                 Loading ...
//                             </option>`;

//     // Fetch and populate the manufacturers list
//     getDocs(collection(firestore, 'manufacturers'))
//         .then((manufacturers) => {
//             select.innerHTML = '';
//             const option = document.createElement('option');
//             option.innerHTML = 'Please select';
//             select.appendChild(option);

//             manufacturers.forEach((manufacturerDoc) => {
//                 const manufacturer = manufacturerDoc.data();
//                 const option = document.createElement('option');
//                 option.setAttribute('value', manufacturer.manufacturerId);
//                 option.innerHTML = `${manufacturer.name}`;
//                 select.appendChild(option);
//             });
//         })
//         .catch((error) => {
//             console.error('Error getting manufacturers:', error);
//         });
// }

// Add Color Shade
// document.getElementById('saveColorShadeButton').addEventListener('click', async () => {
//     const colorShadeName = document.getElementById('colorShadeName').value;
//     const selectedManufacturerId = document.getElementById('colorShadeManufacturer').value;
//     if (colorShadeName && selectedManufacturerId) {
//         try {
//             const colorShadeId = await addColorShade(selectedManufacturerId, colorShadeName);
//             console.log('Color Shade added successfully');
//             displayMessage('Color Shade added successfully!', 'success');
//             // Update the color shades list in the modal
//             document.querySelector('#colorShadeManufacturer').dispatchEvent(new Event('change'));
//             document.getElementById('colorShadeName').value = ''; // Clear the input field
//         } catch (error) {
//             console.error('Error adding color shade:', error);
//         }
//     }
// });

//----------------------------- Product Size in Ltr-----------------------------
// const openProductSizemodel=document.getElementById('addProductSizeButton');
// openProductSizemodel.addEventListener('click',()=>{
//     console.log("1");
//     document.getAnimations('productSizeName').value='';
//     populateProductSizeList();
// })

// //populate product sizelist
// function populateProductSizeList(){
//     const productSizeList=document.querySelector('#productSizeList');
//     getDocs(collection(firestore,'sizes'))
//     .then((sizes)=>{
//         productSizeList.innerHTML='';
//         sizes.forEach((productSizeDoc)=>{
//             const productSize=productSizeDoc.data();
//             // console.log(productSize);
//             const row =document.createElement('tr');
//             row.innerHTML=`
//              <td>${productSize.size}</td>
//              <button class="btn btn-sm btn-primary edit ms-2">Edit</button>&nbsp
//              <button class="btn btn-sm btn-danger delete ms-2">Delete</button>
//             `
//             productSizeList.appendChild(row);
//             row.querySelector('.edit').addEventListener('click',async()=>editProductSize(productSize.sizeId,productSize.size));
//             row.querySelector('.delete').addEventListener('click',async()=>deleteProductSize(productSize.sizeId,productSize.size))
//         })
//     })
// }

// Add the productSize Inside the Model
// document.querySelector('#saveProductSizeButton').addEventListener('click',async()=>{
//     const productSizeName = document.querySelector('#productSizeName').value;
//     if(productSizeName){
//         try{
//             const ProductSizeId=await addProductSize(productSizeName);
//             console.log('productSize uploaded successfully');
//             displayMessage('ProductSize Uploaded','success');
//             populateProductSizeList();
//             document.querySelector('#productSizeName').value='';
//         }catch(error){
//             console.log('Error adding product:',error);
//         }
//     }
// })

// async function addProductSize(productSizeName){
//     try {
//         const productSizeRef = collection(firestore, 'sizes');
//         const docRef = await addDoc(productSizeRef, { size: productSizeName,unit:"ltr" });
//         await updateDoc(docRef, { sizeId: docRef.id })
//         // document.querySelector('#productSizeDropdown').addEventListener('click', fetchCategories)
//         return docRef.id;
//     } catch (error) {
//         console.error('Error adding productsize:', error);
//         throw error;
//     }
// }

// Edit product Size 
// async function editProductSize(productsizeId,productSizeName){
//    const updateProductSizeName=prompt('Edit productSize Name',productSizeName);
//    if(updateProductSizeName!==null){
//      const productSizeCollection=collection(firestore,'sizes');
//      const productSizeSnapshot=await getDocs(query(productSizeCollection,where('sizeId','==',productsizeId)));
//     //  console.log(productSizeSnapshot);
//      if(!productSizeSnapshot.empty){
//         // console.log("5")
//         updateDoc(productSizeSnapshot.docs[0].ref,{size:updateProductSizeName})
//         .then(() => {
//             console.log('ProductSize updated successfully');
//             displayMessage('ProductSize updated successfully!', 'success');
//             // document.querySelector('#categoryDropdown').addEventListener('click', fetchCategories)
//             populateProductSizeList();
//         })
//         .catch((error) => {
//             console.error('Error updating productSize:', error);
//         });
//      }
//    }
// }

// delete Product Size
// async function deleteProductSize(productSizeId,productSizeName){
//     const confirmation=confirm("Are you sure you want delete this productSize?",productSizeName);
//     if(confirmation){
//         try{
//             const productSizeCollection = collection(firestore,'sizes');
//             const productSizeSnapshot = await getDocs(query(productSizeCollection,where('sizeId','==',productSizeId)));
//             if(!productSizeSnapshot.empty){
//                 await deleteDoc(productSizeSnapshot.docs[0].ref);
//             }
//             console.log('productSize deleted successfully');
//             displayMessage('productSize deleted successfully!', 'success');
//             // document.querySelector('#categoryDropdown').addEventListener('click', fetchCategories)
//             populateProductSizeList();
//         }catch(error){
//             console.error('Error deleting productsize:', error);
//         }
//     }
// }

// Fetch product Size 
// async function fetchProductSizes() {
//     const select = document.querySelector('#productSizeDropdown')
//     select.innerHTML = `<option value="">
//                                 Loading ...
//                             </option>`
//     const productSizeSnapshot = await getDocs(collection(firestore, 'sizes'))
//     if (!productSizeSnapshot.empty) {
//         select.removeEventListener('click', fetchProductSizes)
//         select.innerHTML = ``
//         const option = document.createElement('option')
//         option.innerHTML = `Please select`
//         select.appendChild(option)
//         productSizeSnapshot.forEach(doc => {
//             const option = document.createElement('option')
//             option.setAttribute('value', doc.data().size)
//             option.setAttribute('data-id', doc.data().sizeId)
//             option.innerHTML = `${doc.data().size}`
//             // console.log(option);
//             select.appendChild(option)
//         })
//     }
//     else {
//         select.innerHTML = `<option value="">Please select</option>`
//         displayMessage('No categories added!', 'danger')
//     }
// }
//------------------------------------------------------------------------------
// Initialize an empty array to store selected colors
// const selectedColors = [];
// document.getElementById('addColorButton').addEventListener('click', function () {
//     const productColorInput = document.getElementById('productColor');
//     const colorValue = productColorInput.value;

//     if (colorValue) {
//         // Add the selected color to the array
//         selectedColors.push(colorValue);

//         // Update the list of selected colors
//         updateSelectedColorsList();

//         // Clear the input field
//         productColorInput.value = "";
//     }
// });

// Function to update the list of selected colors
// function updateSelectedColorsList() {
//     const selectedColorsContainer = document.getElementById('selectedColorsContainer');
//     selectedColorsContainer.innerHTML = "";

//     selectedColors.forEach((color, index) => {
//         const colorContainer = document.createElement('div');
//         colorContainer.classList.add('selected-color-container');

//         const colorInput = document.createElement('input');
//         colorInput.type = 'color';
//         colorInput.value = color;
//         colorInput.disabled = true;

//         const removeButton = document.createElement('button');
//         removeButton.innerText = 'Remove';
//         removeButton.classList.add('remove-button');
//         removeButton.addEventListener('click', () => removeSelectedColor(index));

//         colorContainer.appendChild(colorInput);
//         colorContainer.appendChild(removeButton);

//         selectedColorsContainer.appendChild(colorContainer);
//     });
// }

// Function to remove a selected color
// function removeSelectedColor(index) {
//     selectedColors.splice(index, 1);
//     updateSelectedColorsList();
// }

// // Function to clear the selected colors array
// function clearSelectedColors() {
//     selectedColors.length = 0;
//     updateSelectedColorsList();
// }

// ------------------------ Upload Product ---------------------------------
// Function to upload image and product information
// var newProductArrivalStatusYes = document.querySelector('#new-product-arrival-yes');
// var newProductArrivalStatusNo= document.querySelector('#new-product-arrival-no');
// var newProductArrivalStatus = false;
// newProductArrivalStatusYes.addEventListener('change', function() {
//     if (this.checked) {
//         newProductArrivalStatus = true;
//         newProductArrivalStatusNo.checked = false;
//     }
// });

// newProductArrivalStatusNo.addEventListener('change', function() {
//     if (this.checked) {
//         newProductArrivalStatus = false;
//         newProductArrivalStatusYes.checked = false;
//     }
// });

// async function uploadProduct() {
//     if (newProductArrivalStatusYes.checked) {
//         newProductArrivalStatus = true;
//         newProductArrivalStatusNo.checked=false;
//     }
//     else if (newProductArrivalStatusNo.checked) {
//         newProductArrivalStatus = false;
//     }

//     console.log(newProductArrivalStatus)
//     document.querySelector('#uploadProductButton').disabled = true;
//     document.querySelector('#uploadProductButton').textContent = 'Uploading ...';
//     const productId = generateUniqueProductId();
//     // console.log(productId);
//     const productName = document.getElementById('productName').value;
//     // const productColor = document.getElementById('productColor').value;
//     // const productSize = document.getElementById('productSize').value;
//     const productQuantity = document.getElementById('productQuantity').value;
//     const productPrice = document.getElementById('productPrice').value;
//     const fileInput = document.getElementById('productImage');
//     const manufacturerOption = document.getElementById('manufacturerDropdown').options[document.getElementById('manufacturerDropdown').selectedIndex];
//     const categoryOption = document.getElementById('categoryDropdown').options[document.getElementById('categoryDropdown').selectedIndex];
//     const colorShadeOption = document.getElementById('colorShadeDropdown').options[document.getElementById('colorShadeDropdown').selectedIndex];
//     const productSizeOption = document.getElementById('productSizeDropdown').options[document.getElementById('productSizeDropdown').selectedIndex];
//     const productDescriptionTextarea = document.querySelector('#product-description');
//     const productDetailsTextarea=document.querySelector('#product-details');
//     const productSpecificationsTextarea=document.querySelector('#product-specifications')
//     const selectedFile = fileInput.files[0];

//     if (productName && selectedColors.length > 0  && productQuantity && productPrice && manufacturerOption && categoryOption
//         && colorShadeOption && productSizeOption && selectedFile && productDescriptionTextarea && productDetailsTextarea
//         && productSpecificationsTextarea && (newProductArrivalStatus===true || newProductArrivalStatus===false)) {
//         console.log(newProductArrivalStatus);
//         // const fileName = selectedFile.name;
//         const fileName = `${productId}/${selectedFile.name}`;
//         // console.log(fileName);
//         const folderRef = ref(storage, 'product-images');
//         const imageRef = ref(folderRef, fileName);

//         // Upload the image to Firebase Storage
//         uploadBytes(imageRef, selectedFile)
//             .then(async(snapshot) => {
//                 // Get the download URL of the uploaded image
//                 getDownloadURL(imageRef)
//                     .then(async(downloadURL) => {
//                         let productData = ''
//                             productData = {
//                                 productId: productId,
//                                 name: productName,
//                                 color: selectedColors,
//                                 // size: productSize,
//                                 quantity: productQuantity,
//                                 price: parseFloat(productPrice),
//                                 imageUrl: downloadURL,
//                                 manufacturerName: manufacturerOption.value,
//                                 manufacturerId: manufacturerOption.getAttribute('data-id'),
//                                 categoryName: categoryOption.value,
//                                 categoryId: categoryOption.getAttribute('data-id'),
//                                 colorShadeName: colorShadeOption.value,
//                                 colorShadeId: colorShadeOption.getAttribute('data-id'),
//                                 size:productSizeOption.value,
//                                 sizeId:productSizeOption.getAttribute('data-id'),
//                                 ProductDescription: productDescriptionTextarea.value,
//                                 productDetails:productDetailsTextarea.value,
//                                 productSpecifications:productSpecificationsTextarea.value,
//                                 newProductArrivalStatus:newProductArrivalStatus
//                             };
//                         // Once the image URL is obtained, store product information in Firestore
//                         // Firestore collection for products, add the product data
//                         console.log(productData);
//                         const productsRef =collection(firestore, 'products');
//                         const docRef =await addDoc(productsRef, productData);
//                            await updateDoc(docRef,{productId:docRef.id})
//                             .then(() => {
//                                 displayMessage('Product Uploaded Successfully!', 'success')

//                                 // Clear selected colors after successful upload
//                                 clearSelectedColors();

//                                 document.querySelector('#uploadProductButton').disabled = false;
//                                 document.querySelector('#uploadProductButton').textContent = 'Upload Product';
//                                 // membershipAgentlist();
//                                 document.getElementById('productInfoForm').reset();
//                             })
//                             .catch((error) => {
//                                 document.querySelector('#uploadProductButton').disabled = false;
//                                 document.querySelector('#uploadProductButton').textContent = 'Upload Product';
//                                 console.error('Error adding product information to Firestore:', error);
//                             });
//                     })
//                     .catch((error) => {
//                         document.querySelector('#uploadProductButton').disabled = false;
//                         document.querySelector('#uploadProductButton').textContent = 'Upload Product';
//                         console.error('Error getting image download URL:', error);
//                     });
//             })
//             .catch((error) => {
//                 document.querySelector('#uploadProductButton').disabled = false;
//                 document.querySelector('#uploadProductButton').textContent = 'Upload Product';
//                 console.error('Error uploading image: ', error);
//             });
//     } else {
//         displayMessage('Please fill in all product information and select an image.', 'danger')

//         document.querySelector('#uploadProductButton').disabled = false;
//         document.querySelector('#uploadProductButton').textContent = 'Upload Product';
//         // alert('Please fill in all product information and select an image.');
//     }
// }

// // Add a click event listener to the Upload Product
// const uploadProductButton = document.getElementById('uploadProductButton');
// uploadProductButton.addEventListener('click', uploadProduct);
// 


//*********************************Commission Assignment*******************************
// Function to fetch and display agent posts and commissions
// function fetchAndDisplayCommissions() {
//     const commissionsRef = collection(firestore, 'commission');
//     const commissionTableBody = document.getElementById('commissionTableBody');
//     commissionTableBody.innerHTML = ''; // Clear the table body before adding new data 

//     getDocs(commissionsRef)
//         .then((querySnapshot) => {
//             querySnapshot.forEach((doc) => {
//                 const commissionData = doc.data();
//                 console.log(commissionData)
//                 const commissionId = doc.id;
//                 console.log(commissionId)

//                 // Create a table row for each commission entry
//                 const commissionRow = createCommissionTableRow(commissionData, commissionId);
//                 commissionTableBody.appendChild(commissionRow);
//                 console.log(commissionRow)
//             });
//         })
//         .catch((error) => {
//             console.error('Error fetching commission data:', error);
//         });
// }


// Function to create a table row for a commission entry
// function createCommissionTableRow(commissionData, commissionId) {
//     console.log(commissionId)
//     const commissionRow = document.createElement('tr');
//     commissionRow.innerHTML = `
//                 <td>${commissionData.post || ''}</td>
//                 <td>${commissionData.commission || ''}</td>
//                 <td>
//                     <button type="button" class="update-commission btn btn-primary" data-bs-toggle="modal" 
//                        data-bs-target="#updateCommissionModal" data-id="${commissionId}">Update Commision</button>
//                 </td>
//                 `;

//     // Add click event listeners for the update and delete buttons
//     const updateButton = commissionRow.querySelector('.update-commission');
//     updateButton.addEventListener('click', (event) => {
//         const commissionId = event.target.getAttribute('data-id');
//         console.log(commissionId)
//         openUpdateCommissionModal(commissionId);
//     });
//     return commissionRow;
// }

// Function to open the update commission modal
// function openUpdateCommissionModal(commissionId) {
//     // console.log(commissionId);

//     // Fetch the commission data using the commissionId
//     const commissionsRef = collection(firestore, 'commission');
//     const commissionDocRef = doc(commissionsRef, commissionId);

//     getDoc(commissionDocRef)
//         .then((docSnapshot) => {
//             if (docSnapshot.exists()) {
//                 const commissionData = docSnapshot.data();
//                 console.log(commissionData);

//                 // Set the commission ID in the hidden input field
//                 document.getElementById('commissionIdInput').value = commissionId;

//                 // Set the commission value in the form
//                 document.getElementById('updateCommissionValueInput').value = commissionData.commission;
//             } else {
//                 console.error(`Commission with ID ${commissionId} not found.`);
//             }
//         })
//         .catch((error) => {
//             console.error(`Error fetching commission data: ${error}`);
//         });
// }


// JavaScript to handle the submission of the update commission form
// document.getElementById('updateCommissionForm').addEventListener('submit', function (event) {
//     event.preventDefault();

//     document.querySelector('#update').disabled = true;
//     document.querySelector('#update').textContent = 'Updating ...';

//     // Get the values from the form
//     const commissionId = document.getElementById('commissionIdInput').value;
//     // const post = document.getElementById('updatePostInput').value;
//     const commission = parseFloat(document.getElementById('updateCommissionValueInput').value);

//     // Validate and update the commission data in Firestore
//     if (commissionId && !isNaN(commission)) {
//         const commissionsRef = collection(firestore, 'commission');
//         const commissionDocRef = doc(commissionsRef, commissionId);

//         // Update the commission data
//         updateDoc(commissionDocRef, {
//             // post: post,
//             commission: commission,
//         })
//             .then(() => {
//                 // Commission updated successfully
//                 // You can display a success message or close the modal here
//                 displayMessage('Commission updated successfully!', 'success');
//                 document.querySelector('#update').disabled = false;
//                 document.querySelector('#update').textContent = 'Update';
//                 fetchAndDisplayCommissions();
//             })
//             .catch((error) => {
//                 console.error(`Error updating commission: ${error}`);
//             });
//     } else {
//         // Handle invalid input or display an error message
//         console.error('Invalid input for commission update.');
//     }
// });

//******************************** Membership id *****************************************

//Generate unique membershipId
function generateUniqueMembershipId() {
    const currentDate = new Date();
    const formattedDate = formatDate(currentDate);
    const formattedTime = formatTime(currentDate);

    // Generate a random alphanumeric string
    const randomString = generateRandomString(6);

    // Combine date, time, and random string to create the unique ID
    const membershipId = `${formattedDate}${formattedTime}${randomString}`;
    return membershipId;
}

function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
}

function formatTime(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}${minutes}${seconds}`;
}

function generateRandomString(length) {
    const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        result += charset.charAt(randomIndex);
    }
    return result;
}

//****************************** GenerateUniqueProdcutId **************************************** 

//Unique productId
function generateUniqueProductId() {
    const timestamp = new Date().getTime();
    const randomPart = Math.random().toString(36).substring(2, 10);
    return `${timestamp}_${randomPart}`;
}

function editProduct() {
    // Redirect to product-edit.html with the product ID as a query parameter
    window.location.href = 'product-edit.html';
}

//************************************* toast message **********************************

//display message function
/**
 * 
 * @param {*} message 
 * @param {*} type 
 * 
 * Toast message
 */
function displayMessage(message, type) {
    // Get the toast container element
    const toastContainer = document.querySelector(".toast-container");

    // Create a clone of the toast template
    const toast = document.querySelector(".toast").cloneNode(true);

    console.log(toast)
    // Set the success message
    toast.querySelector(".compare-note").innerHTML = message;

    //set text type  success/danger
    if (type === "danger") {
        toast.classList.remove("bg-success");
        toast.classList.add("bg-danger");
    } else {
        toast.classList.add("bg-success");
        toast.classList.remove("bg-danger");
    }

    // Append the toast to the container
    toastContainer.appendChild(toast);

    // Initialize the Bootstrap toast and show it
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();

    // Remove the toast after it's closed
    toast.addEventListener("hidden.bs.toast", function () {
        toast.remove();
    });
}

//************************************************************************************

/**
 * 
 * @returns promise
 */
async function fetchNavCategories() {
    const categoryList = document.querySelector('.nav-category')
    const mobileCategoryList = document.querySelector('.mobile-nav-category')

    categoryList.innerHTML = `
    <div class='w-100 d-flex justify-content-center'>
        <div class="spinner-grow text-secondary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    `
    mobileCategoryList.innerHTML = `
    <div class='w-100 d-flex justify-content-center'>
        <div class="spinner-grow text-secondary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    `
    const categorySnapshot = await getDocs(collection(firestore, 'categories'))
    if (categorySnapshot.empty) {
        console.log('from empty')
        resolve()
        return
    }

    categoryList.innerHTML = ``
    mobileCategoryList.innerHTML = ``

    categorySnapshot.forEach(doc => {
        const span = document.createElement('span')
        span.innerHTML = `
        <div class="gi-tab-list nav flex-column nav-pills me-3" id="v-pills-tab"
        role="tablist" aria-orientation="vertical">
            <button class="nav-link" id="v-pills-home-tab" data-bs-toggle="pill"
                data-bs-target="#v-pills-home" type="button" role="tab"
                aria-controls="v-pills-home" aria-selected="true"><a class="text-decoration-none text-black" href="products.html?categoryId=${doc.data().categoryId}">${doc.data().name}</a>
            </button>
        </div>
        `
        categoryList.appendChild(span)

        const list = document.createElement('li')
        list.innerHTML = `
        <a class="text-decoration-none text-black" href="products.html?categoryId=${doc.data().categoryId}">${doc.data().name}</a>
        `
        mobileCategoryList.appendChild(list)
    })
}