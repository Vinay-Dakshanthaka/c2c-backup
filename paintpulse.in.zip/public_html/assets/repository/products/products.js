import {firestore, auth, getCountFromServer, collection, query, where,getDoc,doc} from '../initialize.js'

const produtcsColRef = collection(firestore, 'products')

/**
 * 
 * @param {*} categoryId 
 * @returns category count
 * 
 * @author dev
 */
export async function getCategoryCount(categoryId){
    const q = query(produtcsColRef, where('categoryId', '==', categoryId))
    const count = await getCountFromServer(q)
    return count.data().count
}

/**
 * 
 * @param {*} productId 
 * @returns 
 * Product Detials - {imageUrl, name, category, productDetails, manufacturerName}
 */
export async function getProductDetails(productId){
    const productSnapshot = await getDoc(doc(produtcsColRef, productId))
    if (productSnapshot.exists()){
        return productSnapshot.data()
    }
    return false
}

/**
 * 
 * @param {string} productId 
 * @returns {number} price
 * 
 * @author dev
 */
export async function getProductPrice(productId){
    const productDetails = await getProductDetails(productId)
    return parseFloat(productDetails.price)
}